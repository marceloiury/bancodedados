package com.example.projetobd.request;


import lombok.Data;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;

@Data
public class TicketQtyRequest {

    @Min(value = 0, message = "A quantidade de ingressos deve ser maior ou igual a 0")
    @Max(value = 10, message = "A quantidade de ingressos deve ser menor ou igual a 10")
    private Integer qty;
}
