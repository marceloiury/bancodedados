package com.example.projetobd.entity;

import java.util.Arrays;
import java.util.List;

public enum TicketType {
    ADULT, CHILD, STUDENT, SENIOR, FLAMENGUISTA
}
