package com.example.projetobd.request;

import lombok.Data;

@Data
public class MovieRoomRequest {

    private Long roomId;
    private Long movieId;

}
