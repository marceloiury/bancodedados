package com.example.projetobd;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjetoBdApplication {

    public static void main(String[] args) {
        SpringApplication.run(ProjetoBdApplication.class, args);
    }
}
