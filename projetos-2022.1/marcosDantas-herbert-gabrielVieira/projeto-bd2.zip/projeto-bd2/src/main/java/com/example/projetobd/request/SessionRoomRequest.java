package com.example.projetobd.request;

import lombok.Data;

@Data
public class SessionRoomRequest {

}
