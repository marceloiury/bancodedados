package com.example.projetobd.request;

import com.example.projetobd.entity.TicketType;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class SnacksAndTicketsRequest {
    private Long sessionId;
    private List<TicketType> ticketType;

    private boolean isCreditCard;

    private List<Long> snacksId;
    private ArrayList<Integer> snacksQuantity;
    public SnacksAndTicketsRequest(List<TicketBuyRequest> ticketBuyRequest, SnackOrderCreateRequest snackOrderCreateRequest) {
        this.sessionId = 0L;
        this.ticketType = new ArrayList<>();
        this.isCreditCard = false;
        this.snacksId = snackOrderCreateRequest.getSnacksId();
        this.snacksQuantity = snackOrderCreateRequest.getSnacksQuantity();
        for (TicketBuyRequest ticket : ticketBuyRequest) {
            this.ticketType.add(ticket.getTicketType());
        }
    }


    public SnackOrderCreateRequest createSnackOrderCreateRequest() {
        return new SnackOrderCreateRequest(snacksId, snacksQuantity);
    }

    public List<TicketBuyRequest> createTicketBuyRequest() {
        List<TicketBuyRequest> ticketBuyRequests = new ArrayList<>();
        for (TicketType ticket : ticketType) {
            ticketBuyRequests.add(new TicketBuyRequest(sessionId, ticket, isCreditCard));
        }
        return ticketBuyRequests;
    }

    public TicketBuyRequest[] getTicketBuyRequestList() {
        TicketBuyRequest[] ticketBuyRequests = new TicketBuyRequest[ticketType.size()];
        for (int i = 0; i < ticketType.size(); i++) {
            ticketBuyRequests[i] = new TicketBuyRequest(sessionId, ticketType.get(i), isCreditCard);
        }
        return ticketBuyRequests;
    }
}
