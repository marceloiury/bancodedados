package com.example.projetobd.repository;


public interface SnackOrderRepository extends org.springframework.data.jpa.repository.JpaRepository<com.example.projetobd.entity.SnackOrder, java.lang.Long> {
}
