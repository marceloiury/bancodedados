package com.example.projetobd.entity;

import lombok.*;

import javax.persistence.*;

@Getter
@Setter
@ToString
@Entity
@NoArgsConstructor
@AllArgsConstructor
public class SnackOrder {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @OneToOne
    @JoinColumn(name = "snack_id")
    private Snack snack;

    @ManyToOne(cascade = CascadeType.ALL)
    private Transaction transaction;

    private Integer quantity;

    public SnackOrder(Snack snackById, Integer value) {
        this.snack = snackById;
        this.quantity = value;
    }
}
