#!/bin/bash

# Run Application
# João Pedro Vasconcelos - jpvteixeira99@gmail.com
# First Version: 2022-12-02

streamlit run app.py --server.port 8501
