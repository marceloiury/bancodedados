# Cinema System

Este repositório contém o projeto final da disciplina de Banco de Dados da UFPB, ministrada pelo Prof. Marcelo Iury Oliveira.

Desenvolvido por Itamar Filho, João Pedro Vasconcelos e João Wallace Lucena.

A documentação necessária para rodar esse projeto localmente estão no repositório do ambiente e da aplicação. Primeiramente, rode o ambiente e depois a aplicação para replicar o projeto.
