USE cinemadb;

SET character_set_client = utf8;
SET character_set_connection = utf8;
SET character_set_results = utf8;
SET collation_connection = utf8_general_ci;

INSERT INTO ator (nome) VALUES
	("Robert Downey Jr."),
    ("Chris Evans"),
    ("Chris Hemsworth"),
    ("Elizabeth Olsen"),
    ("Tessa Thompson");

INSERT INTO genero (nome) VALUES
	("Ação"),
    ("Aventura"),
    ("Comédia"),
    ("Comédia Romântica"),
    ("Drama"),
    ("Terror");

INSERT INTO filme (titulo, sinopse, censura, duracao, nacional, data_lancamento, id_genero) VALUES
	(
		"Vingadores: Ultimato",
		"Após Thanos eliminar metade das criaturas vivas, os Vingadores têm de lidar com a perda de amigos e entes queridos. Com Tony Stark vagando perdido no espaço sem água e comida, Steve Rogers e Natasha Romanov lideram a resistência contra o titã louco.",
		"+12",
        180,
        "Estrangeiro",
        '2019-10-15',
        1
    ),
    (
		"Top Gun: Maverick",
		"Depois de mais de 30 anos de serviço como um dos principais aviadores da Marinha, Pete 'Maverick' Mitchell está de volta, rompendo os limites como um piloto de testes corajoso. No mundo contemporâneo das guerras tecnológicas, Maverick enfrenta drones e prova que o fator humano ainda é essencial.",
		"+12",
        120,
        "Estrangeiro",
        '2022-10-15',
        2
    ),
    (
        "O Senhor dos Anéis: A Sociedade do Anel",
        "Depois de mais de 30 anos de serviço como um dos principais aviadores da Marinha, Pete 'Maverick' Mitchell está de volta, rompendo os limites como um piloto de testes corajoso. No mundo contemporâneo das guerras tecnológicas, Maverick enfrenta drones e prova que o fator humano ainda é essencial.",
        "+12",
        120,
        "Estrangeiro",
        '2001-10-15',
        2
    ),
    (
        "O Senhor dos Anéis: O Retorno do Rei",
        "Depois de mais de 30 anos de serviço como um dos principais aviadores da Marinha, Pete 'Maverick' Mitchell está de volta, rompendo os limites como um piloto de testes corajoso. No mundo contemporâneo das guerras tecnológicas, Maverick enfrenta drones e prova que o fator humano ainda é essencial.",
        "+12",
        120,
        "Estrangeiro",
        '2001-10-15',
        3
    ),
    (
        "O Senhor dos Anéis: As Duas Torres",
        "Depois de mais de 30 anos de serviço como um dos principais aviadores da Marinha, Pete 'Maverick' Mitchell está de volta, rompendo os limites como um piloto de testes corajoso. No mundo contemporâneo das guerras tecnológicas, Maverick enfrenta drones e prova que o fator humano ainda é essencial.",
        "+12",
        120,
        "Estrangeiro",
        '2001-10-15',
        6
    ),
    (
        "Harry Potter e a Câmara Secreta",
        "Depois de mais de 30 anos de serviço como um dos principais aviadores da Marinha, Pete 'Maverick' Mitchell está de volta, rompendo os limites como um piloto de testes corajoso. No mundo contemporâneo das guerras tecnológicas, Maverick enfrenta drones e prova que o fator humano ainda é essencial.",
        "+12",
        120,
        "Estrangeiro",
        '2001-10-15',
        3
    ),
    (
        "Harry Potter e a Pedra Filosofal",
        "Depois de mais de 30 anos de serviço como um dos principais aviadores da Marinha, Pete 'Maverick' Mitchell está de volta, rompendo os limites como um piloto de testes corajoso. No mundo contemporâneo das guerras tecnológicas, Maverick enfrenta drones e prova que o fator humano ainda é essencial.",
        "+12",
        120,
        "Estrangeiro",
        '2001-10-15',
        2
    ),
    (
        "Adão Negro",
        "Depois de mais de 30 anos de serviço como um dos principais aviadores da Marinha, Pete 'Maverick' Mitchell está de volta, rompendo os limites como um piloto de testes corajoso. No mundo contemporâneo das guerras tecnológicas, Maverick enfrenta drones e prova que o fator humano ainda é essencial.",
        "+12",
        120,
        "Estrangeiro",
        '2001-10-15',
        6
    ),
    (
        "Mulan",
        "Depois de mais de 30 anos de serviço como um dos principais aviadores da Marinha, Pete 'Maverick' Mitchell está de volta, rompendo os limites como um piloto de testes corajoso. No mundo contemporâneo das guerras tecnológicas, Maverick enfrenta drones e prova que o fator humano ainda é essencial.",
        "+12",
        120,
        "Estrangeiro",
        '2001-10-15',
        6
    ),
    (
        "O Diário de Noel",
        "Depois de mais de 30 anos de serviço como um dos principais aviadores da Marinha, Pete 'Maverick' Mitchell está de volta, rompendo os limites como um piloto de testes corajoso. No mundo contemporâneo das guerras tecnológicas, Maverick enfrenta drones e prova que o fator humano ainda é essencial.",
        "+12",
        120,
        "Estrangeiro",
        '2001-10-15',
        4
    );

INSERT INTO filme_tem_ator (id_filme, id_ator, nome_personagem) VALUES
	(1, 1, "Homem de Ferro"),
    (1, 2, "Capitão América"),
    (1, 3, "Thor"),
    (1, 4, "Wanda Maximoff"),
    (1, 5, "Valkyrie"),
    (3, 1, "Sauro"),
    (4, 3, "Harry Potter"),
    (5, 4, "Emma Watson"),
    (6, 3, "Severus Snape"),
    (7, 4, "Draco Malfoy"),
    (7, 5, "Frodo Baggins"),
    (7, 2, "Aragom"),
    (7, 1, "Gollum"),
    (8, 3, "Adão Negro"),
    (9, 5, "Mulan"),
    (10, 2, "Noel");

INSERT INTO sala (nome, capacidade) VALUES
	("Sala 1", 50),
    ("Sala 2", 10),
    ("Sala 3", 5),
    ("Sala 4", 10),
    ("Sala 5", 10),
    ("Sala 6", 10);

INSERT INTO cliente (nome, cpf, email, dia_aniversario, mes_aniversario) VALUES
	("Rosivaldo", "01586493469", "rosivaldosilva@eng.ci.ufpb.br", 2, 3);

INSERT INTO item (nome, valor_unitario, quantidade_estoque) VALUES
	("Pipoca", 5.00, 10),
    ("Pipoca Doce", 7.00, 20),
    ("Chocolate", 10.00, 20),
    ("Batata Frita", 2.00, 20),
    ("Queijo", 8.00, 20);

INSERT INTO sessao (id_sala, id_filme, horario) VALUES
	(1, 1, "2022-11-26 20:30"),
    (2, 1, "2022-11-26 21:15"),

    (3, 7, "2022-11-29 21:45"),
    (4, 5, "2022-11-29 21:30"),
    (5, 6, "2022-11-29 21:00"),

    (6, 2, "2022-12-06 19:00"),
    (1, 1, "2022-12-06 18:00"),
    (2, 2, "2022-12-05 15:00"),

    (5, 3, "2022-12-10 16:00"),
    (6, 4, "2022-12-15 17:30"),

    (4, 5, "2022-12-10 14:00"),
    (1, 7, "2022-11-30 13:30"),

    (2, 8, "2022-12-07 13:30"),
    (2, 8, "2022-12-07 15:30"),
    (2, 8, "2022-12-07 19:30"),
    (2, 8, "2022-12-07 21:30"),

    (2, 9, "2022-12-08 21:30"),
    (5, 9, "2022-12-08 21:30"),
    (3, 9, "2022-12-07 21:30"),

    (4, 10, "2022-12-09 21:30"),
    (3, 10, "2022-12-09 21:30"),
    (2, 10, "2022-12-09 21:30");

INSERT INTO tipo_ingresso (tipo, valor_padrao) VALUES
    ("ADULTO", 36.00),
    ("ESTUDANTE", 36.00),
    ("INFANTIL", 36.00),
    ("IDOSO", 36.00),
    ("FLAMENGUISTA", 0.00),
    ("VASCAINO", 0.00);
