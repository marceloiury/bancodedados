package com.github.rosivaldolucas.domain.services;

import com.github.rosivaldolucas.domain.entities.TipoIngresso;

import java.util.List;

public interface TipoIngressoService {

  List<TipoIngresso> listar();

}
