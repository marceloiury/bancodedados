package com.github.rosivaldolucas.domain;

public class CalculoValorIngressoEstudante implements CalculoValorIngresso {

  @Override
  public Double calcular(final Double valorPadrao) {
    final Double novoValorIngresso = valorPadrao * 0.5;

    return novoValorIngresso;
  }

}
