package com.github.rosivaldolucas.domain.entities;

import jakarta.persistence.*;
import lombok.*;

import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "ator")
public class Ator {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;

  @Column(name = "nome")
  private String nome;

  @OneToMany(mappedBy = "ator", cascade = CascadeType.ALL)
  private Set<FilmeAtor> filmes = new HashSet<>();

  @Override
  public String toString() {
    return "id: " + id + ", nome: " + nome;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
    if (o == null || getClass() != o.getClass()) return false;
    Ator ator = (Ator) o;
    return id.equals(ator.id) && nome.equals(ator.nome);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, nome);
  }

}
