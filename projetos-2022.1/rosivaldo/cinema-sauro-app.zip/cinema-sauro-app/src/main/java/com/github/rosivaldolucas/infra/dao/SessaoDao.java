package com.github.rosivaldolucas.infra.dao;

import com.github.rosivaldolucas.domain.entities.Sessao;
import com.github.rosivaldolucas.infra.conexao.ConexaoFactory;
import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;

import java.util.List;

/**
 *
 * @author rosivaldo
 */
public class SessaoDao {

    private final EntityManager entityManager = ConexaoFactory.obterEntityManager();

    public List<Sessao> busarSessoesDeFilme(final Long idFilme) {
        final String query = "SELECT DISTINCT s FROM Filme as f INNER JOIN Sessao as s ON ?1 = s.filme.id";

        final TypedQuery<Sessao> typedQuery = this.entityManager.createQuery(query, Sessao.class);
        typedQuery.setParameter(1, idFilme);

        final List<Sessao> sessoesDisponiveisFilme = typedQuery.getResultList();

        return sessoesDisponiveisFilme;
    }
    
}
