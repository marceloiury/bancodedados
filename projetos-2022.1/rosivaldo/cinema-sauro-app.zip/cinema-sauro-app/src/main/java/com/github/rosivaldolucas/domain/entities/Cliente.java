package com.github.rosivaldolucas.domain.entities;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "cliente")
public class Cliente {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;

  @Column(name = "nome")
  private String nome;

  @Column(name = "cpf")
  private String cpf;

  @Column(name = "email")
  private String email;

  @Column(name = "dia_aniversario")
  private Integer diaAniversario;

  @Column(name = "mes_aniversario")
  private Integer mesAniversario;

  @OneToMany(mappedBy = "cliente", cascade = CascadeType.ALL)
  private List<Compra> compras = new ArrayList<>();

  @OneToMany(mappedBy = "cliente", cascade = CascadeType.ALL)
  private List<Voucher> vouchers = new ArrayList<>();

}
