package com.github.rosivaldolucas.infra.dao;

import com.github.rosivaldolucas.domain.entities.Genero;
import com.github.rosivaldolucas.infra.conexao.ConexaoFactory;
import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;

import java.util.List;
import java.util.Optional;

public class GeneroDao {

  private final EntityManager entityManager = ConexaoFactory.obterEntityManager();

  public List<Genero> listar() {
    final String query = "SELECT g FROM Genero as g";

    final TypedQuery<Genero> typedQuery = this.entityManager.createQuery(query, Genero.class);

    final List<Genero> generos = typedQuery.getResultList();

    return generos;
  }

  public Optional<Genero> buscarPorId(final Long id) {
    final String query = "SELECT g FROM Genero as g WHERE g.id = ?1";

    final TypedQuery<Genero> typedQuery = this.entityManager.createQuery(query, Genero.class);
    typedQuery.setParameter(1, id);

    final Genero genero = typedQuery.getSingleResult();

    return Optional.ofNullable(genero);
  }

  public Optional<Genero> buscarPorNome(final String nome) {
    final String query = "SELECT g FROM Genero as g WHERE g.id = ?1";

    final TypedQuery<Genero> typedQuery = this.entityManager.createQuery(query, Genero.class);
    typedQuery.setParameter(1, nome);

    final Genero genero = typedQuery.getSingleResult();

    return Optional.ofNullable(genero);
  }

}
