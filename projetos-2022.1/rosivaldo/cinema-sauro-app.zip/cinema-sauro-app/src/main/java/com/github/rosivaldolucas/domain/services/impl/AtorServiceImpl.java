package com.github.rosivaldolucas.domain.services.impl;

import com.github.rosivaldolucas.domain.entities.Ator;
import com.github.rosivaldolucas.domain.services.AtorService;
import com.github.rosivaldolucas.infra.dao.AtorDao;

import java.util.Optional;

public class AtorServiceImpl  implements AtorService {

  private final AtorDao atorDao = new AtorDao();

  @Override
  public Ator buscarPorNome(final String nome) {
    return this.atorDao.buscarPorNome(nome);
  }

}
