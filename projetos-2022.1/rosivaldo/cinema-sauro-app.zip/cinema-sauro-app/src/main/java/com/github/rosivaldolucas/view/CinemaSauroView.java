package com.github.rosivaldolucas.view;

import com.github.rosivaldolucas.api.controllers.FilmeController;
import com.github.rosivaldolucas.api.controllers.impl.FilmeControllerImpl;
import com.github.rosivaldolucas.domain.entities.Filme;

import javax.swing.*;
import java.util.List;

/**
 *
 * @author rosivaldo
 */
public class CinemaSauroView extends javax.swing.JFrame {

    private final CadastroFilmeView cadastroFilmeView = new CadastroFilmeView();
    
    private final DefaultListModel<Filme> modelFilmes = new DefaultListModel<>();
        
    private final FilmeController filmeController = new FilmeControllerImpl();
    
    private List<Filme> filmes;
    
    public CinemaSauroView() {
        initComponents();
        setLocationRelativeTo(null);
        
        this.carregarListaFilmes();
        
        this.filmesList.setModel(this.modelFilmes);
    }

    public void carregarListaFilmes() {
        this.filmes = this.filmeController.listar();
        
        for (final Filme filme : this.filmes) {
            this.modelFilmes.addElement(filme);
        }
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        nomeCinemaLB = new javax.swing.JLabel();
        cadastroFilmesBT = new javax.swing.JButton();
        consultarFilmesBT = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        filmesList = new javax.swing.JList<>();
        jLabel1 = new javax.swing.JLabel();
        reservarIngresso = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Cinema Sauro");

        jPanel1.setBackground(new java.awt.Color(0, 104, 204));

        nomeCinemaLB.setFont(new java.awt.Font("Chilanka", 1, 24)); // NOI18N
        nomeCinemaLB.setForeground(new java.awt.Color(255, 255, 255));
        nomeCinemaLB.setText("Cinema Sauro");
        nomeCinemaLB.setName(""); // NOI18N

        cadastroFilmesBT.setText("Cadastro de Filmes");
        cadastroFilmesBT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cadastroFilmesBTActionPerformed(evt);
            }
        });

        consultarFilmesBT.setText("Consultar Filmes");
        consultarFilmesBT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                consultarFilmesBTActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(cadastroFilmesBT, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(21, 21, 21)
                        .addComponent(nomeCinemaLB)
                        .addGap(0, 15, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(consultarFilmesBT, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(nomeCinemaLB)
                .addGap(18, 18, 18)
                .addComponent(cadastroFilmesBT)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(consultarFilmesBT)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        filmesList.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        filmesList.setName("listaFilmes"); // NOI18N
        jScrollPane1.setViewportView(filmesList);

        jLabel1.setFont(new java.awt.Font("Chilanka", 0, 36)); // NOI18N
        jLabel1.setText("Filmes Disponíveis");

        reservarIngresso.setText("Reservar ingresso");
        reservarIngresso.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                reservarIngressoActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 766, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(reservarIngresso, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 285, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(reservarIngresso, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(18, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void cadastroFilmesBTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cadastroFilmesBTActionPerformed
        this.cadastroFilmeView.setVisible(true);
    }//GEN-LAST:event_cadastroFilmesBTActionPerformed

    private void reservarIngressoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_reservarIngressoActionPerformed
        final Filme filmeSelecionado = this.filmesList.getSelectedValue();
        
        final ReservarIngressoView reservarIngressoView = new ReservarIngressoView(filmeSelecionado);
        reservarIngressoView.setVisible(true);
    }//GEN-LAST:event_reservarIngressoActionPerformed

    private void consultarFilmesBTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_consultarFilmesBTActionPerformed
        final ConsultaFilmeView consultaFilmeView = new ConsultaFilmeView();
        
        consultaFilmeView.setVisible(true);
    }//GEN-LAST:event_consultarFilmesBTActionPerformed
    
    public static void main(String args[]) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(CinemaSauroView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }

        java.awt.EventQueue.invokeLater(() -> {
            new CinemaSauroView().setVisible(true);
        });
    }
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton cadastroFilmesBT;
    private javax.swing.JButton consultarFilmesBT;
    private javax.swing.JList<Filme> filmesList;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel nomeCinemaLB;
    private javax.swing.JButton reservarIngresso;
    // End of variables declaration//GEN-END:variables
}
