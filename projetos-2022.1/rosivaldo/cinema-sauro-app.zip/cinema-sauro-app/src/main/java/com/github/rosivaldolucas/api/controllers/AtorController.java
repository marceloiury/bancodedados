package com.github.rosivaldolucas.api.controllers;

import com.github.rosivaldolucas.domain.entities.Ator;

public interface AtorController {

  Ator buscarPorNome(final String nome);

}
