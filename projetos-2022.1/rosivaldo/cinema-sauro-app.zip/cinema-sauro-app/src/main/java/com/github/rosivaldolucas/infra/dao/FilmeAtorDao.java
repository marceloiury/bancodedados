package com.github.rosivaldolucas.infra.dao;

public class FilmeAtorDao {

}
