package com.github.rosivaldolucas.infra.dao;

import com.github.rosivaldolucas.domain.entities.Voucher;
import com.github.rosivaldolucas.infra.conexao.ConexaoFactory;
import jakarta.persistence.EntityManager;

public class VoucherDao {

  private final EntityManager entityManager = ConexaoFactory.obterEntityManager();

  public void salvar(final Voucher voucher) {
    this.entityManager.getTransaction().begin();
    this.entityManager.persist(voucher);
    this.entityManager.getTransaction().commit();
  }

}
