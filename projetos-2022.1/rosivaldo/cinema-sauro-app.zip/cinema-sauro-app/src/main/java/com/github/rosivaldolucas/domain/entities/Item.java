package com.github.rosivaldolucas.domain.entities;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "item")
public class Item {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;

  @Column(name = "nome")
  private String nome;

  @Column(name = "valor_unitario")
  private Double valorUnitario;

  @Column(name = "quantidade_estoque")
  private Integer quantidadeEstoque;

  @Override
  public String toString() {
    return this.nome + ", " + "Valor: R$ " + this.valorUnitario + ", " + "Qtd: " + this.quantidadeEstoque;
  }
  
  public String obterTotalItens(final int quantidadeComprada) {
    return this.nome + ", " + "Valor: R$ " + this.valorUnitario + ", " + "Quantidade Comprada " + quantidadeComprada + ", " + "Valor Total: " + this.valorUnitario * quantidadeComprada;
  }

}
