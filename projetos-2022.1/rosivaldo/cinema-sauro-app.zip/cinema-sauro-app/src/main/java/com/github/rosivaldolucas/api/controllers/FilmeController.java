package com.github.rosivaldolucas.api.controllers;

import com.github.rosivaldolucas.api.dtos.FilmeDto;
import com.github.rosivaldolucas.domain.entities.Filme;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

public interface FilmeController {

  List<Filme> listar();

  List<Filme> buscarPorNome(final String nome);

  List<Filme> buscarPorGenero(final String genero);

  List<Filme> buscarPorDataSessao(final LocalDate dataSessao);

  List<Filme> buscarPorHoraSessao(final LocalTime horaSessao);

  void cadastrar(final FilmeDto filmeDto);

}
