package com.github.rosivaldolucas.domain.entities;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "ingresso")
public class Ingresso {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;

  @Column(name = "valor")
  private Double valor;

  @ManyToOne
  @JoinColumn(name = "id_sessao")
  private Sessao sessao;

  @ManyToOne
  @JoinColumn(name = "id_tipo_ingresso")
  private TipoIngresso tipoIngresso;

}
