package com.github.rosivaldolucas.domain.services.impl;

import com.github.rosivaldolucas.domain.entities.Compra;
import com.github.rosivaldolucas.domain.entities.CompraIngresso;
import com.github.rosivaldolucas.domain.entities.CompraItem;
import com.github.rosivaldolucas.domain.entities.TipoIngresso;
import com.github.rosivaldolucas.domain.services.CompraService;
import com.github.rosivaldolucas.infra.dao.CompraDao;

public class CompraServiceImpl implements CompraService {

  private final CompraDao compraDao = new CompraDao();

  @Override
  public void processar(final Compra compra) {
    for (final CompraIngresso compraIngresso : compra.getCompraIngressos()) {
      compraIngresso.setCompra(compra);
    }

    for (final CompraItem compraItem : compra.getCompraItens()) {
      compraItem.setCompra(compra);
    }

    this.compraDao.salvar(compra);
  }

}
