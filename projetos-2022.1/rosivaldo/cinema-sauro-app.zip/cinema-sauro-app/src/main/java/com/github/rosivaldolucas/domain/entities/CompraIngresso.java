package com.github.rosivaldolucas.domain.entities;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "compra_tem_ingresso")
public class CompraIngresso {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;

  @Column(name = "quantidade_comprada")
  private Integer quantidadeComprada;

  @Column(name = "valor_unitario")
  private Double valorUnitario;

  @Column(name = "valor_total")
  private Double valorTotal;

  @ManyToOne
  @JoinColumn(name = "id_compra")
  private Compra compra;

  @ManyToOne(cascade = CascadeType.PERSIST)
  @JoinColumn(name = "id_ingresso")
  private Ingresso ingresso;

}
