package com.github.rosivaldolucas.domain.services.impl;

import com.github.rosivaldolucas.domain.entities.Genero;
import com.github.rosivaldolucas.domain.services.GeneroService;
import com.github.rosivaldolucas.infra.dao.GeneroDao;

import java.util.List;
import java.util.Optional;

public class GeneroServiceImpl implements GeneroService {

  private final GeneroDao generoDao = new GeneroDao();

  public GeneroServiceImpl() { }

  @Override
  public List<Genero> listar() {
    return this.generoDao.listar();
  }

  @Override
  public Genero buscarPorId(final Long id) {
    final Optional<Genero> genero = this.generoDao.buscarPorId(id);

    if (genero.isEmpty()) {
      throw new RuntimeException("Genero não encontrado");
    }

    return genero.get();
  }

  @Override
  public Genero buscarPorNome(final String nome) {
    final Optional<Genero> genero = this.generoDao.buscarPorNome(nome);

    if (genero.isEmpty()) {
      throw new RuntimeException("Genero não encontrado");
    }

    return genero.get();
  }

}
