package com.github.rosivaldolucas.domain.entities;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "voucher")
public class Voucher {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;

  @Column(name = "codigo")
  private String codigo;

  @Column(name = "valor")
  private Double valor;

  @Column(name = "data_expiracao")
  private LocalDate dataExpiracao;

  @Column(name = "valido")
  private Boolean isValido;

  @ManyToOne
  @JoinColumn(name = "id_cliente")
  private Cliente cliente;

}
