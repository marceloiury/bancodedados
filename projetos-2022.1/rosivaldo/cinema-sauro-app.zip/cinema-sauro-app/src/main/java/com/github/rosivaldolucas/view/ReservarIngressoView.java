package com.github.rosivaldolucas.view;

import com.github.rosivaldolucas.api.controllers.ItemController;
import com.github.rosivaldolucas.api.controllers.SessaoController;
import com.github.rosivaldolucas.api.controllers.TipoIngressoController;
import com.github.rosivaldolucas.api.controllers.impl.ItemControllerImpl;
import com.github.rosivaldolucas.api.controllers.impl.SessaoControllerImpl;
import com.github.rosivaldolucas.api.controllers.impl.TipoIngressoControllerImpl;
import com.github.rosivaldolucas.api.dtos.DadosCompraDto;
import com.github.rosivaldolucas.api.dtos.DadosCompraPagamentoDto;
import com.github.rosivaldolucas.domain.entities.*;

import javax.swing.*;
import java.util.ArrayList;
import java.util.List;

public class ReservarIngressoView extends javax.swing.JFrame {

    private Filme filme;
    private Double valorTotalCompra = 0D;
    
    private final List<CompraItem> compraIntens = new ArrayList<>();
    private final List<CompraIngresso> compraIngressos = new ArrayList<>();

    private final DefaultListModel<Item> modelItens = new DefaultListModel<>();
    private final DefaultListModel<TipoIngresso> modelTipoIngressos = new DefaultListModel<>();
    private final DefaultListModel<Sessao> modelSessoes = new DefaultListModel<>();
    private final DefaultListModel<DadosCompraDto> modelDadosCompraDto = new DefaultListModel<>();

    private final ItemController itemController = new ItemControllerImpl();
    private final TipoIngressoController tipoIngressoController = new TipoIngressoControllerImpl();
    private final SessaoController sessaoController = new SessaoControllerImpl();

    public ReservarIngressoView() { }

    public ReservarIngressoView(final Filme filme) {
        this.initComponents();
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        this.filme = filme;
        this.filmeTF.setText(this.filme.getTitulo());
        this.dadosReservaList.setModel(this.modelDadosCompraDto);

        this.inicializarListagens();
    }

    private void inicializarListagens() {
        final List<Item> itensDisponiveis = this.itemController.listar();
        this.modelItens.addAll(itensDisponiveis);

        final List<TipoIngresso> tipoIngressosDisponiveis = this.tipoIngressoController.listar();
        this.modelTipoIngressos.addAll(tipoIngressosDisponiveis);

        final List<Sessao> sessaosDisponiveis = this.sessaoController.buscarSessoesDeFilme(this.filme.getId());
        this.modelSessoes.addAll(sessaosDisponiveis);

        this.itensList.setModel(this.modelItens);
        this.ingressosList.setModel(this.modelTipoIngressos);
        this.salasList.setModel(this.modelSessoes);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        salasList = new javax.swing.JList<>();
        jLabel2 = new javax.swing.JLabel();
        filmeTF = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        adicionarDadosBT = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        itensList = new javax.swing.JList<>();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane4 = new javax.swing.JScrollPane();
        dadosReservaList = new javax.swing.JList<>();
        jLabel9 = new javax.swing.JLabel();
        valorTotalLB = new javax.swing.JLabel();
        irPagamentoBT = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        quantidadeIngressosTF = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        ingressosList = new javax.swing.JList<>();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        quantidadeItensTF = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(0, 104, 204));

        jLabel1.setFont(new java.awt.Font("Dialog", 0, 36)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Reservar Filme");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addComponent(jLabel1)
                .addContainerGap(18, Short.MAX_VALUE))
        );

        jScrollPane1.setViewportView(salasList);

        jLabel2.setText("Filme:");

        filmeTF.setEditable(false);

        jLabel3.setText("Salas e Sessões Disponíveis:");

        adicionarDadosBT.setText("Adicionar");
        adicionarDadosBT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                adicionarDadosBTActionPerformed(evt);
            }
        });

        jScrollPane2.setViewportView(itensList);

        jPanel2.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        dadosReservaList.setEnabled(false);
        jScrollPane4.setViewportView(dadosReservaList);

        jLabel9.setText("Valor Total:");

        valorTotalLB.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        valorTotalLB.setText("R$ 0,00");

        irPagamentoBT.setText("Ir para pagamento");
        irPagamentoBT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                irPagamentoBTActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane4, javax.swing.GroupLayout.DEFAULT_SIZE, 746, Short.MAX_VALUE)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel9)
                            .addComponent(valorTotalLB))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(irPagamentoBT, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane4)
                .addGap(18, 18, 18)
                .addComponent(jLabel9)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(valorTotalLB)
                    .addComponent(irPagamentoBT, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        jLabel4.setText("Quantidade Ingressos:");

        jLabel5.setText("Dados da Compra");

        jLabel6.setText("Ingressos:");

        jScrollPane3.setViewportView(ingressosList);

        jLabel7.setText("Itens Disponíveis:");

        jLabel8.setText("Quantidade Itens:");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(filmeTF, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(jScrollPane2, javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 270, Short.MAX_VALUE)
                                .addComponent(jLabel3, javax.swing.GroupLayout.Alignment.LEADING))
                            .addComponent(jLabel7))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel4)
                            .addComponent(jLabel6)
                            .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 270, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel8)
                            .addComponent(quantidadeIngressosTF)
                            .addComponent(quantidadeItensTF)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addComponent(adicionarDadosBT, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel5)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(jLabel5))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addContainerGap())
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(filmeTF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(17, 17, 17)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(jLabel6))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel7)
                            .addComponent(jLabel4))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(quantidadeIngressosTF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jLabel8)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(quantidadeItensTF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(adicionarDadosBT)))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
    
    private void adicionarDadosBTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_adicionarDadosBTActionPerformed
        final Sessao sessaoSelecionada = this.salasList.getSelectedValue();
        
        if (sessaoSelecionada == null) {
            JOptionPane.showMessageDialog(null, "Escolha a sala e sessão para adicionar.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        final int capacidadeSalaSessaoDisponiveis = sessaoSelecionada.getSala().getCapacidade();
        
        final Item itemSelecionado = this.itensList.getSelectedValue();
        CompraItem compraItem = null;

        int quantidadeCompraItem = 0;
        double valorUnitarioItemSelecionado = 0D;
        double valorTotalCompraItem = 0D;
        
        if (itemSelecionado != null) {
            if (quantidadeCompraItem > itemSelecionado.getQuantidadeEstoque()) {
                JOptionPane.showMessageDialog(null, "Quantidade maior do que a disponível em estoque.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            quantidadeCompraItem = Integer.parseInt(this.quantidadeItensTF.getText());
            valorUnitarioItemSelecionado += itemSelecionado.getValorUnitario();

            compraItem = new CompraItem();
            compraItem.setItem(itemSelecionado);
            compraItem.setQuantidadeComprada(quantidadeCompraItem);
            compraItem.setValorUnitario(valorUnitarioItemSelecionado);
            compraItem.setValorTotal(valorTotalCompraItem);

            this.compraIntens.add(compraItem);
        }
        
        valorTotalCompraItem = valorUnitarioItemSelecionado * quantidadeCompraItem;
        
        final TipoIngresso tipoIngressoSelecionado = this.ingressosList.getSelectedValue();
        final int quantidadeCompradaIngresso = Integer.parseInt(this.quantidadeIngressosTF.getText());
        
        if (itemSelecionado != null) {
            if (quantidadeCompradaIngresso > capacidadeSalaSessaoDisponiveis) {
                JOptionPane.showMessageDialog(null, "Não há vagas disponíveis para essa sessão/sala", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
        }
        
        final double valorUnitarioIngresso = tipoIngressoSelecionado.getValorPadrao();
        final double valorTotalIngresso = valorUnitarioIngresso * quantidadeCompradaIngresso;
        
        final Ingresso ingresso = new Ingresso();
        ingresso.setSessao(sessaoSelecionada);
        ingresso.setTipoIngresso(tipoIngressoSelecionado);
        ingresso.setValor(valorUnitarioIngresso);
        
        final CompraIngresso compraIngresso = new CompraIngresso();
        compraIngresso.setQuantidadeComprada(quantidadeCompradaIngresso);
        compraIngresso.setValorUnitario(valorUnitarioIngresso);
        compraIngresso.setValorTotal(valorTotalIngresso);
        compraIngresso.setIngresso(ingresso);
        
        this.compraIngressos.add(compraIngresso);
        
        this.valorTotalCompra += valorTotalCompraItem + valorTotalIngresso;
        this.valorTotalLB.setText("R$ "+ this.valorTotalCompra.toString());
        
        final DadosCompraDto dadosCompraDto = new DadosCompraDto();
        dadosCompraDto.setHorarioSessao(sessaoSelecionada.getHorario().toLocalTime().toString());
        dadosCompraDto.setNomeItem((itemSelecionado == null) ? null : itemSelecionado.getNome());
        dadosCompraDto.setNomeSala(sessaoSelecionada.getSala().getNome());
        dadosCompraDto.setQuantidadeItens(quantidadeCompraItem);
        dadosCompraDto.setQuantidadeIngressos(quantidadeCompradaIngresso);
        dadosCompraDto.setTipoIngresso(tipoIngressoSelecionado.getTipo());
        dadosCompraDto.setValorTotalIngressos(valorTotalIngresso);
        dadosCompraDto.setValorTotalItens(valorTotalCompraItem);
        
        this.modelDadosCompraDto.addElement(dadosCompraDto);
    }//GEN-LAST:event_adicionarDadosBTActionPerformed

    private void irPagamentoBTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_irPagamentoBTActionPerformed
        final DadosCompraPagamentoDto dadosCompraPagamentoDto = new DadosCompraPagamentoDto();
        dadosCompraPagamentoDto.setFilme(this.filme);
        dadosCompraPagamentoDto.setValorTotalCompra(this.valorTotalCompra);
        dadosCompraPagamentoDto.setCompraIngressos(this.compraIngressos);
        dadosCompraPagamentoDto.setCompraIntens(this.compraIntens);
        
        final PagamentoCompraView pagamentoCompraView = new PagamentoCompraView(dadosCompraPagamentoDto);
        pagamentoCompraView.setVisible(true);
    }//GEN-LAST:event_irPagamentoBTActionPerformed

    public static void main(String args[]) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ReservarIngressoView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ReservarIngressoView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ReservarIngressoView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ReservarIngressoView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ReservarIngressoView().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton adicionarDadosBT;
    private javax.swing.JList<DadosCompraDto> dadosReservaList;
    private javax.swing.JTextField filmeTF;
    private javax.swing.JList<TipoIngresso> ingressosList;
    private javax.swing.JButton irPagamentoBT;
    private javax.swing.JList<Item> itensList;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JTextField quantidadeIngressosTF;
    private javax.swing.JTextField quantidadeItensTF;
    private javax.swing.JList<Sessao> salasList;
    private javax.swing.JLabel valorTotalLB;
    // End of variables declaration//GEN-END:variables
}
