package com.github.rosivaldolucas.view;

import com.github.rosivaldolucas.api.controllers.ClienteController;
import com.github.rosivaldolucas.api.controllers.CompraController;
import com.github.rosivaldolucas.api.controllers.impl.ClienteControllerImpl;
import com.github.rosivaldolucas.api.controllers.impl.CompraControllerImpl;
import com.github.rosivaldolucas.api.dtos.DadosCompraPagamentoDto;
import com.github.rosivaldolucas.domain.entities.*;
import com.github.rosivaldolucas.domain.enums.TipoPagamentoEnum;
import com.github.rosivaldolucas.domain.services.impl.VoucherService;
import jakarta.persistence.NoResultException;

import javax.swing.*;
import java.time.LocalDate;
import java.util.List;
import java.util.Random;

public class PagamentoCompraView extends javax.swing.JFrame {

    private Double valorTotal = 0D;
    private Double valorDesconto = 0D;
    private Double valorSubtotal = 0D;
    private Cliente clienteCompra;
    private Voucher voucher;

    private DadosCompraPagamentoDto dadosCompraPagamentoDto;
    
    private final DefaultListModel<String> modelItens = new DefaultListModel<>();
    private final DefaultListModel<String> modelSessoes = new DefaultListModel<>();

    private final ClienteController clienteController = new ClienteControllerImpl();
    private final CompraController compraController = new CompraControllerImpl();
    private final VoucherService voucherService = new VoucherService();

    public PagamentoCompraView() { }
    
    public PagamentoCompraView(final DadosCompraPagamentoDto dadosCompraPagamentoDto) {
        initComponents();
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        this.dadosCompraPagamentoDto = dadosCompraPagamentoDto;

        this.inicializarListagens(this.dadosCompraPagamentoDto);
        this.itensList.setModel(this.modelItens);
        this.sessoesList.setModel(modelSessoes);
        
        this.nomeClienteLB.setVisible(false);

        this.valorTotal = dadosCompraPagamentoDto.getValorTotalCompra();

        this.nomeFilmeLB.setText(this.dadosCompraPagamentoDto.getFilme().getTitulo());
        this.valorTotalLB.setText("R$ " + this.valorTotal);
        
        this.valorSubtotal = this.valorTotal;
        
        this.subtotalLB.setText("R$ " + this.valorSubtotal);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        clienteTF = new javax.swing.JTextField();
        adicionarClienteBT = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        voucherTF = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        numeroCartaoTF = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        dinheiroTF = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        nomeClienteLB = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        nomeFilmeLB = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        sessoesList = new javax.swing.JList<>();
        jLabel12 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        itensList = new javax.swing.JList<>();
        jLabel11 = new javax.swing.JLabel();
        subtotalLB = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        valorVoucherLB = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        valorTotalLB = new javax.swing.JLabel();
        finalizarCompraBT = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(0, 104, 204));

        jLabel1.setFont(new java.awt.Font("Dialog", 0, 36)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Pagamento Compra");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addContainerGap(586, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(jLabel1)
                .addContainerGap(19, Short.MAX_VALUE))
        );

        jLabel2.setText("Cliente:");

        adicionarClienteBT.setText("Adicionar");
        adicionarClienteBT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                adicionarClienteBTActionPerformed(evt);
            }
        });

        jPanel2.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jLabel4.setText("Voucher:");

        voucherTF.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                voucherTFFocusLost(evt);
            }
        });

        jLabel5.setText("Pagamento Cartão (Número):");

        jLabel7.setText("Pagamento Dinheiro:");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(voucherTF, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(numeroCartaoTF)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel7)
                            .addComponent(jLabel5))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(dinheiroTF))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(jLabel5))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(voucherTF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(numeroCartaoTF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel7)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(dinheiroTF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(16, Short.MAX_VALUE))
        );

        jLabel3.setText("Dados Pagamento:");

        jPanel3.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jLabel6.setText("Cliente da compra:");

        nomeClienteLB.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        nomeClienteLB.setText("nomeCliente");

        jLabel8.setText("Filme:");

        nomeFilmeLB.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        nomeFilmeLB.setText("nomeFilme");

        jLabel10.setText("Sessões reservadas:");

        sessoesList.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { "Ingresso: Meia, Sessão: 16:30, Qauntidade Ingresso: 10, Valor Total: 50.00" };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        sessoesList.setEnabled(false);
        jScrollPane1.setViewportView(sessoesList);

        jLabel12.setText("Itens selecionados:");

        itensList.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { "Item: Pipoca, Quantidade comprada: 10, Valor Total: 50.00" };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        itensList.setEnabled(false);
        jScrollPane2.setViewportView(itensList);

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(jLabel6)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(nomeClienteLB))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(jLabel8)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(nomeFilmeLB))
                            .addComponent(jLabel10)
                            .addComponent(jLabel12))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(jScrollPane2))
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(nomeClienteLB))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(nomeFilmeLB))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel10)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel12)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(16, 16, 16))
        );

        jLabel11.setText("Subtotal Compra:");

        subtotalLB.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        subtotalLB.setText("R$ 0,00");

        jLabel14.setText("Valor Desconto Voucher:");

        valorVoucherLB.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        valorVoucherLB.setText("R$ 0,00");

        jLabel16.setText("Valor Total:");

        valorTotalLB.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        valorTotalLB.setText("R$ 0,00");

        finalizarCompraBT.setText("Finalizar compra");
        finalizarCompraBT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                finalizarCompraBTActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(jLabel2)
                        .addGroup(layout.createSequentialGroup()
                            .addComponent(clienteTF, javax.swing.GroupLayout.PREFERRED_SIZE, 320, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(adicionarClienteBT))
                        .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(jLabel3)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel11)
                            .addComponent(subtotalLB))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(valorVoucherLB)
                            .addComponent(jLabel14)))
                    .addComponent(jLabel16)
                    .addComponent(valorTotalLB))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(finalizarCompraBT, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, 312, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(finalizarCompraBT, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 15, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(clienteTF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(adicionarClienteBT))
                        .addGap(18, 18, 18)
                        .addComponent(jLabel3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel11)
                            .addComponent(jLabel14))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(subtotalLB)
                            .addComponent(valorVoucherLB))
                        .addGap(35, 35, 35)
                        .addComponent(jLabel16)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(valorTotalLB)
                        .addGap(26, 26, 26))))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void finalizarCompraBTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_finalizarCompraBTActionPerformed
        final Compra compra = new Compra();
        compra.setCliente(clienteCompra);
        compra.setDesconto(this.valorDesconto);
        compra.setSubtotal(this.valorSubtotal);
        compra.setValorTotal(this.valorTotal);
        compra.setVoucher(this.voucher);
        compra.setCompraIngressos(this.dadosCompraPagamentoDto.getCompraIngressos());
        compra.setCompraItens(this.dadosCompraPagamentoDto.getCompraIntens());

        final Pagamento pagamento = new Pagamento();

        final String numeroCartao = this.numeroCartaoTF.getText();
        final String dinheiro = this.dinheiroTF.getText();

        if (!numeroCartao.equals("") && this.numeroCartaoTF.getText() != null) {
            pagamento.setTipoPagamento(TipoPagamentoEnum.CARTAO_CREDITO);
            pagamento.setValor(this.valorTotal);
        } else if (!dinheiro.equals("") && this.dinheiroTF.getText() != null) {
            pagamento.setTipoPagamento(TipoPagamentoEnum.DINHEIRO);
            pagamento.setValor(Double.parseDouble(dinheiro));
        }
        
        compra.setPagamento(pagamento);
        
        try {
            this.compraController.processar(compra);
        } catch (final Exception ex) {
            ex.printStackTrace();

            JOptionPane.showMessageDialog(null, "Erro ao realizar a compra do ingresso.", "Erro", JOptionPane.ERROR_MESSAGE);
        }

        JOptionPane.showMessageDialog(null, "Compra ingresso realizado com sucesso.", "Sucesso", JOptionPane.INFORMATION_MESSAGE);

        // gerar voucher
        final Random gerador = new Random();

        String numero = "";

        numero = numero.concat(String.valueOf(gerador.nextInt())).replace("-", "");

        final Double valor = 10D;

        final Voucher novoVoucher = new Voucher();
        novoVoucher.setValor(valor);
        novoVoucher.setCodigo(numero);
        novoVoucher.setDataExpiracao(LocalDate.now());
        novoVoucher.setIsValido(Boolean.TRUE);
        novoVoucher.setCliente(this.clienteCompra);

        this.voucherService.inserir(novoVoucher);

        final String mensagem = "Cliente: " + this.clienteTF.getText() + "\n" +
                "Código Voucher: " + numero + "\n" +
                "Valor Voucher: " + valor + "\n\n" +
                "Obrigado e um bom filme";

        JOptionPane.showMessageDialog(null, mensagem, "Sucesso", JOptionPane.INFORMATION_MESSAGE);

        ReservarIngressoView reservarIngressoView = new ReservarIngressoView();
        reservarIngressoView.setVisible(false);
        this.setVisible(false);
    }//GEN-LAST:event_finalizarCompraBTActionPerformed

    private void voucherTFFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_voucherTFFocusLost
        final String codigoVoucher = this.voucherTF.getText();

        if (codigoVoucher == null || codigoVoucher.equals("")) {
            return;
        }

        final Voucher voucherCliente;

        try {
            voucherCliente = this.clienteController.buscarVoucher(this.clienteCompra.getId(), codigoVoucher);
        } catch (final NoResultException ex) {
            JOptionPane.showMessageDialog(null, "Voucher não encontrado", "Erro", JOptionPane.ERROR_MESSAGE);

            this.voucherTF.setText("");

            return;
        }

        final Double valor = voucherCliente.getValor();

        this.valorVoucherLB.setText("R$ " + valor);

        final double novoValor = this.valorTotal - valor;
        
        this.valorDesconto = valor;

        this.valorTotalLB.setText("R$ " + novoValor);
        
        this.voucher = voucherCliente;
    }//GEN-LAST:event_voucherTFFocusLost

    private void adicionarClienteBTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_adicionarClienteBTActionPerformed
        final String cliente = this.clienteTF.getText();
        
        final Cliente clienteBuscado = this.clienteController.buscarPorNome(cliente);
        
        this.nomeClienteLB.setText(clienteBuscado.getNome());
        this.nomeClienteLB.setVisible(true);
        
        this.clienteCompra = clienteBuscado;
    }//GEN-LAST:event_adicionarClienteBTActionPerformed

    private void inicializarListagens(final DadosCompraPagamentoDto dadosCompraPagamentoDto) {
        final List<CompraItem> compraItens = dadosCompraPagamentoDto.getCompraIntens();
        final List<CompraIngresso> compraIngressos = dadosCompraPagamentoDto.getCompraIngressos();
    
        for (final CompraItem compraItem : compraItens) {
            final Item item = compraItem.getItem();
            
            this.modelItens.addElement(item.obterTotalItens(compraItem.getQuantidadeComprada()));
        }
        
        for (final CompraIngresso compraIngresso : compraIngressos) {
            final TipoIngresso tipoIngresso = compraIngresso.getIngresso().getTipoIngresso();
            final Sessao sessao = compraIngresso.getIngresso().getSessao();
            
            final String dadosLista = tipoIngresso.getTipo() + ", " + "Sessão: " + sessao.getHorario().toLocalTime().toString() + ", " + "Quantidade Comprada: " + compraIngresso.getQuantidadeComprada() + ", " + "Valor Total: " + compraIngresso.getValorTotal();
            
            this.modelSessoes.addElement(dadosLista);
        }
        
    }
    
    public static void main(String args[]) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(PagamentoCompraView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(PagamentoCompraView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(PagamentoCompraView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(PagamentoCompraView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new PagamentoCompraView().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton adicionarClienteBT;
    private javax.swing.JTextField clienteTF;
    private javax.swing.JTextField dinheiroTF;
    private javax.swing.JButton finalizarCompraBT;
    private javax.swing.JList<String> itensList;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JLabel nomeClienteLB;
    private javax.swing.JLabel nomeFilmeLB;
    private javax.swing.JTextField numeroCartaoTF;
    private javax.swing.JList<String> sessoesList;
    private javax.swing.JLabel subtotalLB;
    private javax.swing.JLabel valorTotalLB;
    private javax.swing.JLabel valorVoucherLB;
    private javax.swing.JTextField voucherTF;
    // End of variables declaration//GEN-END:variables
}
