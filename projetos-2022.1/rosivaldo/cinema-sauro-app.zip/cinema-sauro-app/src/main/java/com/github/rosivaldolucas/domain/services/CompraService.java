package com.github.rosivaldolucas.domain.services;

import com.github.rosivaldolucas.domain.entities.Compra;

public interface CompraService {

  void processar(final Compra compra);

}
