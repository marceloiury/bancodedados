package com.github.rosivaldolucas.domain.entities;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "compra")
public class Compra {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;

  @Column(name = "subtotal")
  private Double subtotal;

  @Column(name = "desconto")
  private Double desconto;

  @Column(name = "valor_total")
  private Double valorTotal;

  @OneToOne
  @JoinColumn(name = "id_voucher")
  private Voucher voucher;

  @ManyToOne
  @JoinColumn(name = "id_cliente")
  private Cliente cliente;

  @ManyToOne(cascade = CascadeType.ALL)
  @JoinColumn(name = "id_pagamento")
  private Pagamento pagamento;

  @OneToMany(mappedBy = "compra", cascade = CascadeType.ALL)
  private List<CompraItem> compraItens = new ArrayList<>();

  @OneToMany(mappedBy = "compra", cascade = CascadeType.ALL)
  private List<CompraIngresso> compraIngressos = new ArrayList<>();

}
