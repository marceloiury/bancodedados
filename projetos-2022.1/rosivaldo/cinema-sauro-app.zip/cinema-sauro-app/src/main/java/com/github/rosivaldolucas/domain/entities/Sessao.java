package com.github.rosivaldolucas.domain.entities;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;

/**
 *
 * @author rosivaldo
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "sessao")
public class Sessao {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "horario")
    private LocalDateTime horario;

    @ManyToOne
    @JoinColumn(name = "id_filme")
    private Filme filme;

    @ManyToOne
    @JoinColumn(name = "id_sala")
    private Sala sala;

    @Override
    public String toString() {
        return this.sala.getNome() + ", " + "Capacidade: " + this.sala.getCapacidade() + ", " + "Sessão: " + this.horario.toLocalDate() + " " + this.horario.toLocalTime().getHour() + ":" + this.horario.toLocalTime().getMinute();
    }
}
