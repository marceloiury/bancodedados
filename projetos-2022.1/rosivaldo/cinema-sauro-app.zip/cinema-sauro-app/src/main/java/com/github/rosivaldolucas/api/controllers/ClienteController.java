package com.github.rosivaldolucas.api.controllers;

import com.github.rosivaldolucas.domain.entities.Cliente;
import com.github.rosivaldolucas.domain.entities.Voucher;

public interface ClienteController {

  Cliente buscarPorNome(final String nome);

  Voucher buscarVoucher(final Long idCliente, final String codigoVoucher);

}
