package com.github.rosivaldolucas.domain.entities;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "filme_tem_ator")
public class FilmeAtor {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;

  @Column(name = "nome_personagem")
  private String nomePersonagem;

  @ManyToOne
  @JoinColumn(name = "id_filme")
  private Filme filme;

  @ManyToOne
  @JoinColumn(name = "id_ator")
  private Ator ator;

}
