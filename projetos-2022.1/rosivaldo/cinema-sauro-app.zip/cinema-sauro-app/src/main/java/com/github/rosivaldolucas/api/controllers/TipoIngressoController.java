package com.github.rosivaldolucas.api.controllers;

import com.github.rosivaldolucas.domain.entities.TipoIngresso;

import java.util.List;

public interface TipoIngressoController {

  List<TipoIngresso> listar();

}
