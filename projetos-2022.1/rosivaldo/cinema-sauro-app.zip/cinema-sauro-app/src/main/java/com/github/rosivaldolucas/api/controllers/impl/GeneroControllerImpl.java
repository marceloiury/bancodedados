package com.github.rosivaldolucas.api.controllers.impl;

import com.github.rosivaldolucas.api.controllers.GeneroController;
import com.github.rosivaldolucas.domain.entities.Genero;
import com.github.rosivaldolucas.domain.services.GeneroService;
import com.github.rosivaldolucas.domain.services.impl.GeneroServiceImpl;
import java.util.List;

/**
 *
 * @author rosivaldo
 */
public class GeneroControllerImpl implements GeneroController{

    private final GeneroService generoService = new GeneroServiceImpl();
    
    @Override
    public List<Genero> listar() {
        return this.generoService.listar();
    }
    
}
