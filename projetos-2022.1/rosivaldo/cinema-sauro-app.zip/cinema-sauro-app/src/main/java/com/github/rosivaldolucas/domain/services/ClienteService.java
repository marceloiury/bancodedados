package com.github.rosivaldolucas.domain.services;

import com.github.rosivaldolucas.domain.entities.Cliente;
import com.github.rosivaldolucas.domain.entities.Voucher;

public interface ClienteService {

  Cliente buscarPorNome(final String nome);

  Voucher buscarVoucher(final Long idCliente, final String codigoVoucher);

}
