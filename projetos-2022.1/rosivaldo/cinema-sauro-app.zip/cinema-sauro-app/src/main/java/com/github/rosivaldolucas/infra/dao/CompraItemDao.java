package com.github.rosivaldolucas.infra.dao;

import com.github.rosivaldolucas.domain.entities.CompraItem;
import com.github.rosivaldolucas.infra.conexao.ConexaoFactory;
import jakarta.persistence.EntityManager;

public class CompraItemDao {

  private final EntityManager entityManager = ConexaoFactory.obterEntityManager();

  public void salvar(final CompraItem compraItem) {
    this.entityManager.persist(compraItem);
  }

}
