package com.github.rosivaldolucas.domain;

import com.github.rosivaldolucas.domain.enums.TipoIngressoEnum;

public interface CalculoValorIngresso {

  Double calcular(final Double valorPadrao);

  static CalculoValorIngresso obterCalculoIngresso(final String tipoIngresso) {
    final CalculoValorIngresso calculoValorIngresso = TipoIngressoEnum.valueOf(tipoIngresso).getCalculoValorIngresso();

    return calculoValorIngresso;
  }

}
