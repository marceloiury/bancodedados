package com.github.rosivaldolucas.api.dtos;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 *
 * @author rosivaldo
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class DadosCompraDto {

    private String tipoIngresso;
    private Integer quantidadeIngressos;
    private Double valorTotalIngressos;
    private String horarioSessao;
    private String nomeSala;
    private String nomeItem;
    private Integer quantidadeItens;
    private Double valorTotalItens;

    @Override
    public String toString() {
        return "Ingresso: " + this.tipoIngresso + ", " + "Qtd Ingressos: " + this.quantidadeIngressos + ", " + "Valor: " + this.valorTotalIngressos + ", "
                + "Sessão: " + this.horarioSessao + ", " + "Sala: " + this.nomeSala + ", " + "Item: " + this.nomeItem + ", " + "Qtd Itens: " + this.quantidadeItens
                + ", " + "Valor: " + this.valorTotalItens;
    }

}
