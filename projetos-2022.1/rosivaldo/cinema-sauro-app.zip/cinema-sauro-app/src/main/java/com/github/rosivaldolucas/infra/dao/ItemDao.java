package com.github.rosivaldolucas.infra.dao;

import com.github.rosivaldolucas.domain.entities.Item;
import com.github.rosivaldolucas.infra.conexao.ConexaoFactory;
import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;

import java.util.List;

public class ItemDao {

  private final EntityManager entityManager = ConexaoFactory.obterEntityManager();

  public List<Item> listar() {
    final String query = "SELECT i FROM Item as i WHERE i.quantidadeEstoque > 0";

    final TypedQuery<Item> typedQuery = this.entityManager.createQuery(query, Item.class);

    final List<Item> itensDisponiveis = typedQuery.getResultList();

    return itensDisponiveis;
  }

}
