package com.github.rosivaldolucas.api.dtos;

import com.github.rosivaldolucas.domain.entities.Ator;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class AtorDto {

  private Ator ator;
  private String nomePersonagem;

}
