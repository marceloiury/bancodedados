package com.github.rosivaldolucas.domain.services.impl;

import com.github.rosivaldolucas.domain.entities.CompraItem;
import com.github.rosivaldolucas.infra.dao.CompraItemDao;

public class CompraItemService {

  private final CompraItemDao compraItemDao = new CompraItemDao();

  public void inserir(final CompraItem compraItem) {
    this.compraItemDao.salvar(compraItem);
  }

}
