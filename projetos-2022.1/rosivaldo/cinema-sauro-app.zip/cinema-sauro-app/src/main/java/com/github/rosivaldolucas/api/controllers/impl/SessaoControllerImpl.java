package com.github.rosivaldolucas.api.controllers.impl;

import com.github.rosivaldolucas.api.controllers.SessaoController;
import com.github.rosivaldolucas.domain.entities.Sessao;
import com.github.rosivaldolucas.domain.services.SessaoService;
import com.github.rosivaldolucas.domain.services.impl.SessaoServiceImpl;

import java.util.List;

public class SessaoControllerImpl implements SessaoController {

  private final SessaoService sessaoService = new SessaoServiceImpl();

  @Override
  public List<Sessao> buscarSessoesDeFilme(final Long idFilme) {
    return this.sessaoService.buscarSessoesDeFilme(idFilme);
  }
  
}
