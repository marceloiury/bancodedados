package com.github.rosivaldolucas.domain.enums;

import com.github.rosivaldolucas.domain.*;

public enum TipoIngressoEnum {

  ADULTO(new CalculoValorIngressoAdulto()),
  ESTUDANTE(new CalculoValorIngressoEstudante()),
  INFANTIL(new CalculoValorIngressoInfantil()),
  IDOSO(new CalcularValorIngressoIdoso()),
  FLAMENGUISTA(new CalculoValorIngressoFlamengo()),
  VASCAINO(new CalculoValorIngressoVascaino());

  private final CalculoValorIngresso calculoValorIngresso;

  TipoIngressoEnum(final CalculoValorIngresso calculoValorIngresso) {
    this.calculoValorIngresso = calculoValorIngresso;
  }

  public CalculoValorIngresso getCalculoValorIngresso() {
    return calculoValorIngresso;
  }

}
