package com.github.rosivaldolucas.domain.enums;

public enum TipoPagamentoEnum {

  CARTAO_CREDITO,
  DINHEIRO

}
