package com.github.rosivaldolucas.domain.services;

import com.github.rosivaldolucas.domain.entities.Item;

import java.util.List;

public interface ItemService {

  List<Item> listar();

}
