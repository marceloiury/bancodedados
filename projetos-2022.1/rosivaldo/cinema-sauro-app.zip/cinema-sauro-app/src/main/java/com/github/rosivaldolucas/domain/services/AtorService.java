package com.github.rosivaldolucas.domain.services;

import com.github.rosivaldolucas.domain.entities.Ator;

public interface AtorService {

  Ator buscarPorNome(final String nome);

}
