package com.github.rosivaldolucas.infra.dao;

import com.github.rosivaldolucas.domain.entities.TipoIngresso;
import com.github.rosivaldolucas.infra.conexao.ConexaoFactory;
import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;

import java.util.List;

public class TipoIngressoDao {

  private final EntityManager entityManager = ConexaoFactory.obterEntityManager();

  public List<TipoIngresso> listar() {
    final String query = "SELECT ti FROM TipoIngresso as ti";

    this.entityManager.clear();

    final TypedQuery<TipoIngresso> typedQuery = this.entityManager.createQuery(query, TipoIngresso.class);

    final List<TipoIngresso> tiposIngresso = typedQuery.getResultList();

    return tiposIngresso;
  }

}
