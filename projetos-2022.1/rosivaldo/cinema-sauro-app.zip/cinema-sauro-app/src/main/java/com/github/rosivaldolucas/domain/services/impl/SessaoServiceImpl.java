package com.github.rosivaldolucas.domain.services.impl;

import com.github.rosivaldolucas.domain.entities.Sessao;
import com.github.rosivaldolucas.domain.services.SessaoService;
import com.github.rosivaldolucas.infra.dao.SessaoDao;

import java.util.List;

public class SessaoServiceImpl implements SessaoService {

  private final SessaoDao sessaoDao = new SessaoDao();

  @Override
  public List<Sessao> buscarSessoesDeFilme(final Long idFilme) {
    return this.sessaoDao.busarSessoesDeFilme(idFilme);
  }

}
