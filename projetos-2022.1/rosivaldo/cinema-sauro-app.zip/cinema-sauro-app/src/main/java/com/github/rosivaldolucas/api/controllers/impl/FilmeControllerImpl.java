package com.github.rosivaldolucas.api.controllers.impl;

import com.github.rosivaldolucas.api.controllers.FilmeController;
import com.github.rosivaldolucas.api.dtos.FilmeDto;
import com.github.rosivaldolucas.domain.entities.Filme;
import com.github.rosivaldolucas.domain.services.FilmeService;
import com.github.rosivaldolucas.domain.services.impl.FilmeServiceImpl;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

public class FilmeControllerImpl implements FilmeController {

  private final FilmeService filmeService = new FilmeServiceImpl();

  @Override
  public List<Filme> listar() {
    return this.filmeService.listar();
  }

  @Override
  public List<Filme> buscarPorNome(final String nome) {
    return this.filmeService.buscarPorNome(nome);
  }

  @Override
  public List<Filme> buscarPorGenero(final String genero) {
    return this.filmeService.buscarPorGenero(genero);
  }

  @Override
  public List<Filme> buscarPorDataSessao(final LocalDate dataSessao) {
    return this.filmeService.buscarPorDataSessao(dataSessao);
  }

  @Override
  public List<Filme> buscarPorHoraSessao(final LocalTime horaSessao) {
    return this.filmeService.buscarPorHoraSessao(horaSessao);
  }

  @Override
  public void cadastrar(final FilmeDto filmeDto) {
    this.filmeService.cadastrar(filmeDto);
  }

}
