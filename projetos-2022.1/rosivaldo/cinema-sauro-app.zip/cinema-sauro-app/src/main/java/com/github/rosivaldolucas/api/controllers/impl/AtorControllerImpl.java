package com.github.rosivaldolucas.api.controllers.impl;

import com.github.rosivaldolucas.api.controllers.AtorController;
import com.github.rosivaldolucas.domain.entities.Ator;
import com.github.rosivaldolucas.domain.services.AtorService;
import com.github.rosivaldolucas.domain.services.impl.AtorServiceImpl;

public class AtorControllerImpl implements AtorController {

  private final AtorService atorService = new AtorServiceImpl();

  @Override
  public Ator buscarPorNome(final String nome) {
    return this.atorService.buscarPorNome(nome);
  }

}
