package com.github.rosivaldolucas.domain.services;

import com.github.rosivaldolucas.domain.entities.Sessao;

import java.util.List;

public interface SessaoService {

  List<Sessao> buscarSessoesDeFilme(final Long idFilme);

}
