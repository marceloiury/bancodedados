package com.github.rosivaldolucas.api.controllers;

import com.github.rosivaldolucas.domain.entities.Compra;

public interface CompraController {

  void processar(final Compra compra);

}
