package com.github.rosivaldolucas.domain.services.impl;

import com.github.rosivaldolucas.domain.entities.Item;
import com.github.rosivaldolucas.domain.services.ItemService;
import com.github.rosivaldolucas.infra.dao.ItemDao;

import java.util.List;

public class ItemServiceImpl implements ItemService {

  private final ItemDao itemDao = new ItemDao();

  @Override
  public List<Item> listar() {
    return itemDao.listar();
  }

}
