package com.github.rosivaldolucas.domain.services.impl;

import com.github.rosivaldolucas.domain.entities.CompraIngresso;
import com.github.rosivaldolucas.infra.dao.CompraIngressoDao;

public class CompraIngressoService {

  private final CompraIngressoDao compraIngressoDao = new CompraIngressoDao();

  public void inserir(final CompraIngresso compraIngresso) {
    this.compraIngressoDao.salvar(compraIngresso);
  }

}
