package com.github.rosivaldolucas.api.controllers.impl;

import com.github.rosivaldolucas.api.controllers.TipoIngressoController;
import com.github.rosivaldolucas.domain.entities.TipoIngresso;
import com.github.rosivaldolucas.domain.services.TipoIngressoService;
import com.github.rosivaldolucas.domain.services.impl.TipoIngressoServiceImpl;

import java.util.List;

public class TipoIngressoControllerImpl implements TipoIngressoController {

  private final TipoIngressoService tipoIngressoService = new TipoIngressoServiceImpl();

  @Override
  public List<TipoIngresso> listar() {
    return this.tipoIngressoService.listar();
  }

}
