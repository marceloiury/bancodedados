package com.github.rosivaldolucas.api.controllers.impl;

import com.github.rosivaldolucas.api.controllers.ClienteController;
import com.github.rosivaldolucas.domain.entities.Cliente;
import com.github.rosivaldolucas.domain.entities.Voucher;
import com.github.rosivaldolucas.domain.services.ClienteService;
import com.github.rosivaldolucas.domain.services.impl.ClienteServiceImpl;

public class ClienteControllerImpl implements ClienteController {

  private final ClienteService clienteService = new ClienteServiceImpl();

  @Override
  public Cliente buscarPorNome(final String nome) {
    return this.clienteService.buscarPorNome(nome);
  }

  @Override
  public Voucher buscarVoucher(final Long idCliente, final String codigoVoucher) {
    return this.clienteService.buscarVoucher(idCliente, codigoVoucher);
  }

}
