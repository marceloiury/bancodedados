package com.github.rosivaldolucas.domain.services.impl;

import com.github.rosivaldolucas.domain.entities.Cliente;
import com.github.rosivaldolucas.domain.entities.Voucher;
import com.github.rosivaldolucas.domain.services.ClienteService;
import com.github.rosivaldolucas.infra.dao.ClienteDao;

public class ClienteServiceImpl implements ClienteService {

  private final ClienteDao clienteDao = new ClienteDao();

  @Override
  public Cliente buscarPorNome(final String nome) {
    return this.clienteDao.buscarPorNome(nome);
  }

  @Override
  public Voucher buscarVoucher(final Long idCliente, final String codigoVoucher) {
    return this.clienteDao.buscarVoucher(idCliente, codigoVoucher);
  }

}
