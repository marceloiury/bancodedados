package com.github.rosivaldolucas.domain;

public class CalculoValorIngressoFlamengo implements CalculoValorIngresso {

  @Override
  public Double calcular(final Double valorPadrao) {
    return 0.00D;
  }

}
