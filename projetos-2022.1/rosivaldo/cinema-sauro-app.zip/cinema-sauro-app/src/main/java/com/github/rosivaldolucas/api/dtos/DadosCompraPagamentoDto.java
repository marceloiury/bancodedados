package com.github.rosivaldolucas.api.dtos;

import com.github.rosivaldolucas.domain.entities.CompraIngresso;
import com.github.rosivaldolucas.domain.entities.CompraItem;
import com.github.rosivaldolucas.domain.entities.Filme;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;
import lombok.AllArgsConstructor;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class DadosCompraPagamentoDto {

  private Filme filme;
  private Double valorTotalCompra;
  private List<CompraItem> compraIntens = new ArrayList<>();
  private List<CompraIngresso> compraIngressos = new ArrayList<>();

}
