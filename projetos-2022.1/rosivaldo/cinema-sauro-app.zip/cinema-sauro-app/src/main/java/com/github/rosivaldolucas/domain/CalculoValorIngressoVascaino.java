package com.github.rosivaldolucas.domain;

public class CalculoValorIngressoVascaino implements CalculoValorIngresso {

  @Override
  public Double calcular(final Double valorPadrao) {
    return 0.00D;
  }

}
