package com.github.rosivaldolucas.api.controllers;

import com.github.rosivaldolucas.domain.entities.Genero;
import java.util.List;

/**
 *
 * @author rosivaldo
 */
public interface GeneroController {
    
    List<Genero> listar();
    
}
