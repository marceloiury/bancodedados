package com.github.rosivaldolucas.domain.services.impl;

import com.github.rosivaldolucas.domain.entities.Voucher;
import com.github.rosivaldolucas.infra.dao.VoucherDao;

public class VoucherService {

  private final VoucherDao voucherDao = new VoucherDao();

  public void inserir(final Voucher voucher) {
    this.voucherDao.salvar(voucher);
  }

}
