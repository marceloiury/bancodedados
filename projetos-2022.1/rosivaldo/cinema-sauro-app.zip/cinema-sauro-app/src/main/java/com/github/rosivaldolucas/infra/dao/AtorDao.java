package com.github.rosivaldolucas.infra.dao;

import com.github.rosivaldolucas.domain.entities.Ator;
import com.github.rosivaldolucas.infra.conexao.ConexaoFactory;
import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;

public class AtorDao {

  private final EntityManager entityManager = ConexaoFactory.obterEntityManager();

  public Ator buscarPorNome(final String nome) {
    final String query = "SELECT a FROM Ator as a WHERE a.nome = ?1";

    final TypedQuery<Ator> typedQuery = this.entityManager.createQuery(query, Ator.class);
    typedQuery.setParameter(1, nome);

    final Ator ator = typedQuery.getSingleResult();

    return ator;
  }

}
