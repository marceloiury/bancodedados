package com.github.rosivaldolucas.domain.services;

import com.github.rosivaldolucas.domain.entities.Genero;

import java.util.List;

public interface GeneroService {

  List<Genero> listar();

  Genero buscarPorId(final Long id);

  Genero buscarPorNome(final String nome);

}
