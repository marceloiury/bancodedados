package com.github.rosivaldolucas.domain;

public class CalculoValorIngressoInfantil implements CalculoValorIngresso {

  @Override
  public Double calcular(final Double valorPadrao) {
    final Double valorIngresso = valorPadrao * 0.25;

    return valorIngresso;
  }

}
