package com.github.rosivaldolucas.api.controllers.impl;

import com.github.rosivaldolucas.api.controllers.CompraController;
import com.github.rosivaldolucas.domain.entities.Compra;
import com.github.rosivaldolucas.domain.services.CompraService;
import com.github.rosivaldolucas.domain.services.impl.CompraServiceImpl;

public class CompraControllerImpl implements CompraController {

  private final CompraService compraService = new CompraServiceImpl();

  @Override
  public void processar(final Compra compra) {
    this.compraService.processar(compra);
  }

}
