package com.github.rosivaldolucas.infra.dao;

import com.github.rosivaldolucas.domain.entities.Compra;
import com.github.rosivaldolucas.infra.conexao.ConexaoFactory;
import jakarta.persistence.EntityManager;

public class CompraDao {

  private final EntityManager entityManager = ConexaoFactory.obterEntityManager();

  public void salvar(final Compra compra) {
    this.entityManager.getTransaction().begin();
    this.entityManager.persist(compra);
    this.entityManager.getTransaction().commit();
  }

}
