package com.github.rosivaldolucas.infra.dao;

import com.github.rosivaldolucas.domain.entities.CompraIngresso;
import com.github.rosivaldolucas.infra.conexao.ConexaoFactory;
import jakarta.persistence.EntityManager;

public class CompraIngressoDao {

  private final EntityManager entityManager = ConexaoFactory.obterEntityManager();

  public void salvar(final CompraIngresso compraIngresso) {
    this.entityManager.persist(compraIngresso);
  }

}
