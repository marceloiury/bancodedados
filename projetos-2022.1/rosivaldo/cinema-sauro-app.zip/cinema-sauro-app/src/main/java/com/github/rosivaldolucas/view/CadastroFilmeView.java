package com.github.rosivaldolucas.view;

import com.github.rosivaldolucas.api.controllers.AtorController;
import com.github.rosivaldolucas.api.controllers.FilmeController;
import com.github.rosivaldolucas.api.controllers.GeneroController;
import com.github.rosivaldolucas.api.controllers.impl.AtorControllerImpl;
import com.github.rosivaldolucas.api.controllers.impl.FilmeControllerImpl;
import com.github.rosivaldolucas.api.controllers.impl.GeneroControllerImpl;
import com.github.rosivaldolucas.api.dtos.AtorDto;
import com.github.rosivaldolucas.api.dtos.FilmeDto;
import com.github.rosivaldolucas.domain.entities.Ator;
import com.github.rosivaldolucas.domain.entities.Genero;

import javax.swing.*;
import java.time.LocalDate;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

/**
 *
 * @author rosivaldo
 */
public class CadastroFilmeView extends javax.swing.JFrame {

    private final DefaultListModel<String> modeloListaAtores = new DefaultListModel<>();
    private List<Genero> generos;
    
    private final AtorController atorController = new AtorControllerImpl();
    private final GeneroController generoController = new GeneroControllerImpl();
    private final FilmeController filmeController = new FilmeControllerImpl();
    
    public CadastroFilmeView() {
        this.initComponents();
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        
        this.inicializarGeneros();
    
        this.listaAtores.setModel(modeloListaAtores);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        tituloTF = new javax.swing.JTextField();
        cancelarBT = new javax.swing.JButton();
        cadastrarFilmeBT = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        sinopseTA = new javax.swing.JTextArea();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        duracaoTF = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        dataLancamentoTF = new javax.swing.JFormattedTextField();
        jLabel6 = new javax.swing.JLabel();
        generoCB = new javax.swing.JComboBox<>();
        jScrollPane2 = new javax.swing.JScrollPane();
        listaAtores = new javax.swing.JList<>();
        jLabel7 = new javax.swing.JLabel();
        nomeAtorTF = new javax.swing.JTextField();
        adicionarAtorBT = new javax.swing.JButton();
        nacionalTF = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        nomePersonagemTF = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        censuraTF = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(0, 104, 204));

        jLabel1.setFont(new java.awt.Font("Dialog", 0, 36)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Cadastro de Filmes");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(jLabel1)
                .addContainerGap(18, Short.MAX_VALUE))
        );

        jLabel2.setText("Titulo:");

        cancelarBT.setText("Cancelar");
        cancelarBT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cancelarBTActionPerformed(evt);
            }
        });

        cadastrarFilmeBT.setText("Cadastrar");
        cadastrarFilmeBT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cadastrarFilmeBTActionPerformed(evt);
            }
        });

        sinopseTA.setColumns(20);
        sinopseTA.setRows(5);
        jScrollPane1.setViewportView(sinopseTA);

        jLabel3.setText("Sinopse:");

        jLabel4.setText("Duração:");

        jLabel5.setText("Data de Lançamento:");

        try {
            dataLancamentoTF.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("##/##/####")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }

        jLabel6.setText("Gênero:");

        generoCB.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Selecionar" }));

        jScrollPane2.setViewportView(listaAtores);

        jLabel7.setText("Nome Ator:");

        adicionarAtorBT.setText("Adicionar");
        adicionarAtorBT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                adicionarAtorBTActionPerformed(evt);
            }
        });

        jLabel8.setText("Nacionalidade:");

        jLabel9.setText("Nome Personagem:");

        jLabel10.setText("Censura:");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane2)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(generoCB, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel6))
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel8)
                                    .addComponent(nacionalTF, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(nomeAtorTF, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel7))
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel9)
                                    .addComponent(nomePersonagemTF))))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(adicionarAtorBT))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel10)
                                        .addGap(0, 0, Short.MAX_VALUE))
                                    .addComponent(censuraTF, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel3)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(tituloTF, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel2))
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(duracaoTF, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel4))
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel5)
                                    .addComponent(dataLancamentoTF, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(0, 266, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jScrollPane1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cancelarBT)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(cadastrarFilmeBT)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(jLabel4)
                    .addComponent(jLabel5))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(tituloTF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(duracaoTF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(dataLancamentoTF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(jLabel8)
                    .addComponent(jLabel10))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(generoCB, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(nacionalTF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(censuraTF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(jLabel9))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(nomeAtorTF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(adicionarAtorBT)
                    .addComponent(nomePersonagemTF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(cancelarBT, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(cadastrarFilmeBT, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void cancelarBTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cancelarBTActionPerformed
        this.limparCampos();
        
        super.setVisible(false);
    }//GEN-LAST:event_cancelarBTActionPerformed

    private void adicionarAtorBTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_adicionarAtorBTActionPerformed
        final String nomeAtor = this.nomeAtorTF.getText();
        final String nomePersonagem = this.nomePersonagemTF.getText();
        
        if (nomeAtor == null || nomeAtor.equals("")) {
            JOptionPane.showMessageDialog(null, "Nome do ator precisa ser preenchido", "Erro", JOptionPane.ERROR_MESSAGE);
            
            this.limparTextFild(this.nomeAtorTF);
            
            return;
        }
        
        if (nomePersonagem == null || nomePersonagem.equals("")) {
            JOptionPane.showMessageDialog(null, "Nome do personagem precisa ser preenchido", "Erro", JOptionPane.ERROR_MESSAGE);
            
            this.limparTextFild(this.nomePersonagemTF);
            
            return;
        }

        final Iterator<String> nomeAtorIterator = this.modeloListaAtores.elements().asIterator();

        while (nomeAtorIterator.hasNext()) {
            final String nome = nomeAtorIterator.next();

            if (nomeAtor.equals(nome)) {
                JOptionPane.showMessageDialog(null, "Ator já vinculado ao filme", "Erro", JOptionPane.ERROR_MESSAGE);

                this.limparTextFild(this.nomeAtorTF);

                return;
            }
        }
        
        final Ator atorCadastrado = this.atorController.buscarPorNome(nomeAtor);
        
        final String campoLista = "Id: " + atorCadastrado.getId() + ", " + "Nome: " + atorCadastrado.getNome() + ", " + "Personagem: " + nomePersonagem;
        
        this.modeloListaAtores.addElement(campoLista);
        
        this.limparTextFild(this.nomeAtorTF);
        this.limparTextFild(this.nomePersonagemTF);
    }//GEN-LAST:event_adicionarAtorBTActionPerformed

    private void cadastrarFilmeBTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cadastrarFilmeBTActionPerformed
        final FilmeDto filmeDto = new FilmeDto();
        filmeDto.setTitulo(this.tituloTF.getText());
        filmeDto.setDuracao(Integer.valueOf(this.duracaoTF.getText()));
        filmeDto.setSinopse(this.sinopseTA.getText());
        filmeDto.setNacional(this.nacionalTF.getText());
        filmeDto.setCensura(this.censuraTF.getText());

        final String[] dataLan = this.dataLancamentoTF.getText().split("/");

        final LocalDate dataLancamento = LocalDate.of(Integer.parseInt(dataLan[2]), Integer.parseInt(dataLan[1]), Integer.parseInt(dataLan[0]));

        filmeDto.setDataLancamento(dataLancamento);

        final String generoSelecionado = (String) this.generoCB.getSelectedItem();
        
        for (final Genero genero : this.generos) {
            if (genero.getNome().equals(generoSelecionado)) {
                filmeDto.setGenero(genero);
                
                break;
            }
        }

        final Iterator<String> nomeAtoresIterator = this.modeloListaAtores.elements().asIterator();

        final Set<AtorDto> atores = new HashSet<>();
        
        while (nomeAtoresIterator.hasNext()) {
            final String[] dadosAtor = nomeAtoresIterator.next().split(",");

            final Long id = Long.parseLong(dadosAtor[0].split(": ")[1]);
            final String nome = dadosAtor[1].split(": ")[1];
            final String nomePersonagem = dadosAtor[2].split(": ")[1];

            final Ator ator = new Ator();
            ator.setId(id);
            ator.setNome(nome);

            final AtorDto atorDto = new AtorDto(ator, nomePersonagem);

            atores.add(atorDto);
        }

        filmeDto.setAtores(atores);

        this.filmeController.cadastrar(filmeDto);
        
        this.limparCampos();
        
        JOptionPane.showMessageDialog(null, "Cadastro realizado com sucesso.", "Cadastro Realizado", JOptionPane.INFORMATION_MESSAGE);
    }//GEN-LAST:event_cadastrarFilmeBTActionPerformed

    private void limparTextFild(final JTextField textField) {
        textField.setText("");
    }
    
    private void inicializarGeneros() {
        this.generos = this.generoController.listar();
        
        for (final Genero genero : this.generos) {
            this.generoCB.addItem(genero.getNome());
        }
    }
    
    private void verificarCampos() {
        if ((this.tituloTF.getText() == null || this.tituloTF.getText() == "") || (this.duracaoTF.getText() == null || this.duracaoTF.getText() == "")) {
            
        }
    }
    
    private void limparCampos() {
        this.tituloTF.setText("");
        this.duracaoTF.setText("");
        this.dataLancamentoTF.setText("");
        this.generoCB.setSelectedIndex(0);
        this.sinopseTA.setText("");
        this.nacionalTF.setText("");
        this.censuraTF.setText("");
        this.modeloListaAtores.clear();
    }
    
    public static void main(String[] args) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(CadastroFilmeView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        
        java.awt.EventQueue.invokeLater(() -> new CadastroFilmeView().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton adicionarAtorBT;
    private javax.swing.JButton cadastrarFilmeBT;
    private javax.swing.JButton cancelarBT;
    private javax.swing.JTextField censuraTF;
    private javax.swing.JFormattedTextField dataLancamentoTF;
    private javax.swing.JTextField duracaoTF;
    private javax.swing.JComboBox<String> generoCB;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JList<String> listaAtores;
    private javax.swing.JTextField nacionalTF;
    private javax.swing.JTextField nomeAtorTF;
    private javax.swing.JTextField nomePersonagemTF;
    private javax.swing.JTextArea sinopseTA;
    private javax.swing.JTextField tituloTF;
    // End of variables declaration//GEN-END:variables
}
