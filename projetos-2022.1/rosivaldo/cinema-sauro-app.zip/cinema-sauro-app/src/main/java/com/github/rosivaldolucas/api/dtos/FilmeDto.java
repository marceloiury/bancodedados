package com.github.rosivaldolucas.api.dtos;

import com.github.rosivaldolucas.domain.entities.Genero;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class FilmeDto {

  private String titulo;
  private String sinopse;
  private String censura;
  private String nacional;
  private Integer duracao;
  private LocalDate dataLancamento;
  private Genero genero;
  private Set<AtorDto> atores = new HashSet<>();

}
