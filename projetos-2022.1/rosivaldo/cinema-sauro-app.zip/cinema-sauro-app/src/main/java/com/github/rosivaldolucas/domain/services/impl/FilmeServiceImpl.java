package com.github.rosivaldolucas.domain.services.impl;

import com.github.rosivaldolucas.api.dtos.FilmeDto;
import com.github.rosivaldolucas.domain.entities.Filme;
import com.github.rosivaldolucas.domain.entities.FilmeAtor;
import com.github.rosivaldolucas.domain.services.FilmeAtorService;
import com.github.rosivaldolucas.domain.services.FilmeService;
import com.github.rosivaldolucas.infra.dao.FilmeDao;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;
import java.util.Set;

public class FilmeServiceImpl implements FilmeService {

  private final FilmeDao filmeDao = new FilmeDao();

  private final FilmeAtorService filmeAtorService = new FilmeAtorServiceImpl();

  @Override
  public List<Filme> listar() {
    return this.filmeDao.listar();
  }

  @Override
  public List<Filme> buscarPorNome(final String nome) {
    return this.filmeDao.buscarPorNome(nome);
  }

  @Override
  public List<Filme> buscarPorGenero(final String genero) {
    return this.filmeDao.buscarPorGenero(genero);
  }

  @Override
  public List<Filme> buscarPorDataSessao(final LocalDate dataSessao) {
    return this.filmeDao.buscarPorDataSessao(dataSessao);
  }

  @Override
  public List<Filme> buscarPorHoraSessao(final LocalTime horaSessao) {
    return this.filmeDao.buscarPorHoraSessao(horaSessao);
  }

  @Override
  public void cadastrar(final FilmeDto filmeDto) {
    final Filme filme = new Filme();
    filme.setSinopse(filmeDto.getSinopse());
    filme.setDuracao(filmeDto.getDuracao());
    filme.setGenero(filmeDto.getGenero());
    filme.setTitulo(filmeDto.getTitulo());
    filme.setNacional(filmeDto.getNacional());
    filme.setCensura(filmeDto.getCensura());

    final Set<FilmeAtor> filmeAtors = this.filmeAtorService.associarFilmeAtor(filme, filmeDto.getAtores());

    filme.setAtores(filmeAtors);

    this.filmeDao.salvar(filme);
  }

}
