package com.github.rosivaldolucas.infra.dao;

import com.github.rosivaldolucas.domain.entities.Cliente;
import com.github.rosivaldolucas.domain.entities.Voucher;
import com.github.rosivaldolucas.infra.conexao.ConexaoFactory;
import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;

public class ClienteDao {

  private final EntityManager entityManager = ConexaoFactory.obterEntityManager();

  public Cliente buscarPorNome(final String nome) {
    final String query = "SELECT c FROM Cliente as c WHERE c.nome = ?1";

    final TypedQuery<Cliente> typedQuery = this.entityManager.createQuery(query, Cliente.class);
    typedQuery.setParameter(1, nome);

    final Cliente clienteBuscado = typedQuery.getSingleResult();

    return clienteBuscado;
  }

  public Voucher buscarVoucher(final Long idCliente, final String codigoVoucher) {
    final String query = "SELECT v FROM Voucher as v INNER JOIN Cliente as c ON v.cliente.id = ?1 WHERE v.codigo = ?2";

    final TypedQuery<Voucher> typedQuery = this.entityManager.createQuery(query, Voucher.class);
    typedQuery.setParameter(1, idCliente);
    typedQuery.setParameter(2, codigoVoucher);

    final Voucher voucherCliente = typedQuery.getSingleResult();

    return voucherCliente;
  }

}
