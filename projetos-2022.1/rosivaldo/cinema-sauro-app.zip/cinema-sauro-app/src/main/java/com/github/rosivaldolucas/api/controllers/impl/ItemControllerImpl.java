package com.github.rosivaldolucas.api.controllers.impl;

import com.github.rosivaldolucas.api.controllers.ItemController;
import com.github.rosivaldolucas.domain.entities.Item;
import com.github.rosivaldolucas.domain.services.ItemService;
import com.github.rosivaldolucas.domain.services.impl.ItemServiceImpl;

import java.util.List;

public class ItemControllerImpl implements ItemController {

  private final ItemService itemService = new ItemServiceImpl();

  @Override
  public List<Item> listar() {
    return itemService.listar();
  }

}
