package com.github.rosivaldolucas.infra.dao;

import com.github.rosivaldolucas.domain.entities.Filme;
import com.github.rosivaldolucas.infra.conexao.ConexaoFactory;
import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

public class FilmeDao {

  private final EntityManager entityManager = ConexaoFactory.obterEntityManager();

  public List<Filme> listar() {
    final String query = "SELECT f FROM Filme as f";

    final TypedQuery<Filme> typedQuery = this.entityManager.createQuery(query, Filme.class);

    final List<Filme> filmes = typedQuery.getResultList();

    return filmes;
  }

  public List<Filme> buscarPorNome(final String nome) {
    final String query = "SELECT f FROM Filme as f WHERE f.titulo LIKE :titulo";

    final TypedQuery<Filme> typedQuery = this.entityManager.createQuery(query, Filme.class);
    typedQuery.setParameter("titulo", "%" + nome + "%");

    final List<Filme> filmes = typedQuery.getResultList();

    return filmes;
  }

  public List<Filme> buscarPorGenero(final String genero) {
    final String query = "SELECT f FROM Filme as f INNER JOIN Genero as g ON f.genero.id = g.id WHERE g.nome = ?1";

    final TypedQuery<Filme> typedQuery = this.entityManager.createQuery(query, Filme.class);
    typedQuery.setParameter(1, genero);

    final List<Filme> filmesGenero = typedQuery.getResultList();

    return filmesGenero;
  }

  public List<Filme> buscarPorDataSessao(final LocalDate dataSessao) {
    final String query = "SELECT f FROM Filme as f INNER JOIN Sessao as s ON f.id = s.filme.id WHERE FUNCTION('date_format', s.horario, '%Y-%m-%d') LIKE :horario";

    final TypedQuery<Filme> typedQuery = this.entityManager.createQuery(query, Filme.class);
    typedQuery.setParameter("horario", "%" + dataSessao + "%");

    final List<Filme> filmesListdosPorData = typedQuery.getResultList();

    return filmesListdosPorData;
  }

  public List<Filme> buscarPorHoraSessao(final LocalTime horaSessao) {
    final String query = "SELECT f FROM Filme as f INNER JOIN Sessao as s ON f.id = s.filme.id WHERE FUNCTION('date_format', s.horario, '%H:%i') LIKE :horario";

    final TypedQuery<Filme> typedQuery = this.entityManager.createQuery(query, Filme.class);
    typedQuery.setParameter("horario", "%" + horaSessao + "%");

    final List<Filme> filmesListdosPorData = typedQuery.getResultList();

    return filmesListdosPorData;
  }

  public void salvar(final Filme filme) {
    this.entityManager.getTransaction().begin();
    this.entityManager.persist(filme);
    this.entityManager.getTransaction().commit();
    this.entityManager.close();
  }

}
