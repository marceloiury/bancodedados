package com.github.rosivaldolucas.api.controllers;

import com.github.rosivaldolucas.domain.entities.Item;

import java.util.List;

public interface ItemController {

  List<Item> listar();

}
