package com.github.rosivaldolucas.view;

import com.github.rosivaldolucas.api.controllers.FilmeController;
import com.github.rosivaldolucas.api.controllers.impl.FilmeControllerImpl;
import com.github.rosivaldolucas.domain.entities.Filme;
import java.time.LocalDate;
import java.time.LocalTime;

import javax.swing.*;
import java.util.List;

public class ConsultaFilmeView extends javax.swing.JFrame {

    private final DefaultListModel<String> modelDadosList = new DefaultListModel<>();

    private final FilmeController filmeController = new FilmeControllerImpl();

    public ConsultaFilmeView() {
        initComponents();
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        this.dadosList.setModel(this.modelDadosList);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        dadosList = new javax.swing.JList<>();
        nomeFilmeTF = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        consultarFilmeBT = new javax.swing.JButton();
        generoTF = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        dataSessaoFilmeTF = new javax.swing.JFormattedTextField();
        jLabel5 = new javax.swing.JLabel();
        horarioSessaoFilmeTF = new javax.swing.JFormattedTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(0, 104, 204));

        jLabel1.setFont(new java.awt.Font("Dialog", 0, 36)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Consulta de Filmes");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addContainerGap(708, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addComponent(jLabel1)
                .addContainerGap(35, Short.MAX_VALUE))
        );

        dadosList.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        jScrollPane1.setViewportView(dadosList);

        jLabel2.setText("Titulo Filme (LIKE):");

        consultarFilmeBT.setText("Consultar");
        consultarFilmeBT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                consultarFilmeBTActionPerformed(evt);
            }
        });

        jLabel3.setText("Gênero:");

        jLabel4.setText("Data Sessão Filme:");

        try {
            dataSessaoFilmeTF.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("##/##/####")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }

        jLabel5.setText("Horário Sessão Filme:");

        try {
            horarioSessaoFilmeTF.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("##:##")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(consultarFilmeBT)
                            .addComponent(jLabel5)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(horarioSessaoFilmeTF, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(nomeFilmeTF, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE)
                                    .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.LEADING))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(generoTF, javax.swing.GroupLayout.PREFERRED_SIZE, 165, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel3))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel4)
                                    .addComponent(dataSessaoFilmeTF, javax.swing.GroupLayout.PREFERRED_SIZE, 165, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(jLabel3)
                    .addComponent(jLabel4))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(dataSessaoFilmeTF, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(nomeFilmeTF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(generoTF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(horarioSessaoFilmeTF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 27, Short.MAX_VALUE)
                .addComponent(consultarFilmeBT)
                .addGap(26, 26, 26)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void consultarFilmeBTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_consultarFilmeBTActionPerformed
        final String tituloFilme = this.nomeFilmeTF.getText();

        if (!tituloFilme.equals("")) {
            final List<Filme> filmes = this.filmeController.buscarPorNome(tituloFilme);

            this.modelDadosList.clear();

            for (final Filme filme : filmes) {
                this.modelDadosList.addElement(filme.toString());
            }
            
            this.nomeFilmeTF.setText("");
        }

        final String genero = this.generoTF.getText();

        if (!genero.equals("")) {
            final List<Filme> filmes = this.filmeController.buscarPorGenero(genero);

            this.modelDadosList.clear();

            for (final Filme filme : filmes) {
                this.modelDadosList.addElement(filme.toString());
            }
            
            this.generoTF.setText("");
        }
        
        final String dataSessaoFilme = this.dataSessaoFilmeTF.getText();
        
        if (!dataSessaoFilme.equals("  /  /    ")) {
            final String[] dataSessao = dataSessaoFilme.split("/");
            
            final int dia = Integer.parseInt(dataSessao[0]);
            final int mes = Integer.parseInt(dataSessao[1]);
            final int ano = Integer.parseInt(dataSessao[2]);
            
            final LocalDate data = LocalDate.of(ano, mes, dia);
            
            final List<Filme> filmes = this.filmeController.buscarPorDataSessao(data);

            this.modelDadosList.clear();

            for (final Filme filme : filmes) {
                this.modelDadosList.addElement(filme.toString());
            }
            
            this.dataSessaoFilmeTF.setText("");
        }
        
        final String horarioSessao = this.horarioSessaoFilmeTF.getText();
        
        if (!horarioSessao.equals("  :  ")) {
            final String[] horario = horarioSessao.split(":");
            
            final int hora = Integer.parseInt(horario[0]);
            final int minuto = Integer.parseInt(horario[1]);
            
            final LocalTime data = LocalTime.of(hora, minuto, 0);
            
            final List<Filme> filmes = this.filmeController.buscarPorHoraSessao(data);

            this.modelDadosList.clear();

            for (final Filme filme : filmes) {
                this.modelDadosList.addElement(filme.toString());
            }
            
            this.dataSessaoFilmeTF.setText("");
        }
        
    }//GEN-LAST:event_consultarFilmeBTActionPerformed

    public static void main(String args[]) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ConsultaFilmeView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ConsultaFilmeView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ConsultaFilmeView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ConsultaFilmeView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ConsultaFilmeView().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton consultarFilmeBT;
    private javax.swing.JList<String> dadosList;
    private javax.swing.JFormattedTextField dataSessaoFilmeTF;
    private javax.swing.JTextField generoTF;
    private javax.swing.JFormattedTextField horarioSessaoFilmeTF;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField nomeFilmeTF;
    // End of variables declaration//GEN-END:variables
}
