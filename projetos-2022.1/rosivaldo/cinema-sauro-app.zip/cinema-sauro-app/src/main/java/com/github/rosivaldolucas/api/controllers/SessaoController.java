package com.github.rosivaldolucas.api.controllers;

import com.github.rosivaldolucas.domain.entities.Sessao;

import java.util.List;

public interface SessaoController {

  List<Sessao> buscarSessoesDeFilme(final Long idFilme);

}
