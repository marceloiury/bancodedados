package com.github.rosivaldolucas.domain.entities;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "tipo_ingresso")
public class TipoIngresso {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;

  @Column(name = "tipo", updatable = false, insertable = false)
  private String tipo;

  @Column(name = "valor_padrao", updatable = false, insertable = false)
  private Double valorPadrao;

  @Override
  public String toString() {
    return this.tipo + ", " + "Valor: R$ " + this.valorPadrao;
  }
  
}
