package com.github.rosivaldolucas.domain.services.impl;

import com.github.rosivaldolucas.domain.CalculoValorIngresso;
import com.github.rosivaldolucas.domain.entities.TipoIngresso;
import com.github.rosivaldolucas.domain.services.TipoIngressoService;
import com.github.rosivaldolucas.infra.dao.TipoIngressoDao;

import java.util.List;

public class TipoIngressoServiceImpl implements TipoIngressoService {

  private final TipoIngressoDao tipoIngressoDao = new TipoIngressoDao();

  @Override
  public List<TipoIngresso> listar() {
    final List<TipoIngresso> tiposIngressos = this.tipoIngressoDao.listar();

    this.processarValoresIngressos(tiposIngressos);

    return tiposIngressos;
  }

  private void processarValoresIngressos(final List<TipoIngresso> tiposIngresso) {
    for (final TipoIngresso tipoIngresso : tiposIngresso) {
      final Double valorPadrao = tipoIngresso.getValorPadrao();
      final String tipo = tipoIngresso.getTipo();

      final CalculoValorIngresso calculoValorIngresso = CalculoValorIngresso.obterCalculoIngresso(tipo);
      final Double novoValorIngresso = calculoValorIngresso.calcular(valorPadrao);

      tipoIngresso.setValorPadrao(novoValorIngresso);
    }
  }

}
