package com.github.rosivaldolucas.infra.conexao;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

public class ConexaoFactory {

  private static final EntityManagerFactory managerFactory = Persistence.createEntityManagerFactory("cinemadb-pu");
  private static final EntityManager entityManager = managerFactory.createEntityManager();

  private ConexaoFactory() { }

  public static EntityManager obterEntityManager() {
    return entityManager;
  }

}
