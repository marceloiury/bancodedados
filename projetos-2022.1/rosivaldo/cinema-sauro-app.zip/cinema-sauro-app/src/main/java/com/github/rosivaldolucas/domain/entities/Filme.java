package com.github.rosivaldolucas.domain.entities;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "filme")
public class Filme {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;

  @Column(name = "titulo")
  private String titulo;

  @Column(name = "sinopse")
  private String sinopse;

  @Column(name = "censura")
  private String censura;

  @Column(name = "nacional")
  private String nacional;

  @Column(name = "duracao")
  private Integer duracao;

  @Column(name = "data_lancamento")
  private LocalDate dataLancamento;

  @OneToOne
  @JoinColumn(name = "id_genero")
  private Genero genero;

  @OneToMany(mappedBy = "filme", cascade = CascadeType.ALL)
  private Set<FilmeAtor> atores = new HashSet<>();

  @OneToMany(mappedBy = "filme", cascade = CascadeType.ALL)
  private Set<Sessao> sessoes = new HashSet<>();

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
    if (o == null || getClass() != o.getClass()) return false;
    Filme filme = (Filme) o;
    return id.equals(filme.id);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id);
  }

  @Override
  public String toString() {
    String sessoes = "Sessões: ";

    for (final Sessao sessao : this.sessoes) {
      sessoes = sessoes.concat("{ " + sessao.toString() + " }, ");
    }


    return "Titulo: " + this.titulo + ", " + "Duração: " + this.duracao + ", " + "Gênero: " + this.genero.getNome() + ", " + sessoes;
  }
  
}
