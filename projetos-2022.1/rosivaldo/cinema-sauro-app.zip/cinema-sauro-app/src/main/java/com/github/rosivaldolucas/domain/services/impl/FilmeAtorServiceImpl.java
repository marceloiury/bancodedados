package com.github.rosivaldolucas.domain.services.impl;

import com.github.rosivaldolucas.api.dtos.AtorDto;
import com.github.rosivaldolucas.domain.entities.Filme;
import com.github.rosivaldolucas.domain.entities.FilmeAtor;
import com.github.rosivaldolucas.domain.services.FilmeAtorService;
import com.github.rosivaldolucas.infra.dao.FilmeAtorDao;

import java.util.HashSet;
import java.util.Set;

public class FilmeAtorServiceImpl implements FilmeAtorService {

  private final FilmeAtorDao filmeAtorDao = new FilmeAtorDao();

  @Override
  public Set<FilmeAtor> associarFilmeAtor(final Filme filme, Set<AtorDto> atores) {
    final Set<FilmeAtor> filmeAtores = new HashSet<>();

    for (final AtorDto ator : atores) {
      final FilmeAtor filmeAtor = new FilmeAtor();
      filmeAtor.setFilme(filme);
      filmeAtor.setAtor(ator.getAtor());
      filmeAtor.setNomePersonagem(ator.getNomePersonagem());

      filmeAtores.add(filmeAtor);
    }

    return filmeAtores;
  }

}
