package com.github.rosivaldolucas.domain.services;

import com.github.rosivaldolucas.api.dtos.AtorDto;
import com.github.rosivaldolucas.domain.entities.Filme;
import com.github.rosivaldolucas.domain.entities.FilmeAtor;

import java.util.Set;

public interface FilmeAtorService {

  Set<FilmeAtor> associarFilmeAtor(final Filme filme, final Set<AtorDto> atores);

}
