module.exports = {
  singleQuote: true,
  trailingComma: "all",
  arrowParens: "avoid",
};
