export const inputMaps = [
  {
    type: "adult",
    label: "Adulto",
    price: 30,
  },
  {
    type: "child",
    label: "Criança",
    price: 7.5,
  },
  {
    type: "senior",
    label: "Idoso",
    price: 15,
  },
  {
    type: "student",
    label: "Estudante",
    price: 15,
  },
  {
    type: "flamenguista",
    label: "Flamenguista",
    price: 0,
  },
];
